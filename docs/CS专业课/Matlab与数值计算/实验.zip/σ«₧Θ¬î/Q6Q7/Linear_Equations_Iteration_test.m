function Linear_Equations_Iteration_test
clc;
A =[ 1, 2, 2;
    -2,-2,-1;
     2,-3,-2];
b = [3;-3;-1];
disp('**** 线性方程组迭代法测试，线性方程组为：');disp([A,b]);
L = tril(A,-1);  U = triu(A,1);   D = A-L-U; %DLU分解 tril()仅提取主对角线下方的元素。triu()

B1 = -D\(L+U);  B2 = -(L+D)\U;  %雅可比，高斯赛代尔迭代法的B矩阵
p1 = Spectral_Radius(B1);   p2 = Spectral_Radius(B2);%求谱半径 最大特征值
disp(sprintf('雅可比迭代矩阵B谱半径=%8.6f，高斯赛代尔迭代矩阵B谱半径=%8。6f',p1,p2));

tic;x1 = Jaconi_Iterion1(A,b); t1 = toc;
disp('雅可比迭代法一的解为：');disp(x1);
disp(sprintf('耗费的时间为T=%8.6f(s)',t1));%计算运行时间

tic;x2 = Jaconi_Iterion2(A,b); t2 = toc;
disp('雅可比迭代法二的解为：');disp(x2);
disp(sprintf('耗费的时间为T=%8.6f(s)',t2));

tic;x3 =Gauss_Seidel_Iteration1(A,b); t3 = toc;
disp('高斯迭代法一的解为：');disp(x3);
disp(sprintf('耗费的时间为T=%8.6f(s)',t3));

tic;x4 =Gauss_Seidel_Iteration2(A,b); t4 = toc;
disp('高斯迭代法二的解为：');disp(x4);
disp(sprintf('耗费的时间为T=%8.6f(s)',t4));

%雅可比迭代过程解的2-范数曲线显示，揭示收敛性
Show_Convergence(A,b);

%求矩阵谱半径
function p =Spectral_Radius(A)
d = eig(A); %返回一个列向量，其中包含方阵 A 的特征值。
p = max(abs(d));

%雅可比迭代1：采用C语言思路
function x1 = Jaconi_Iterion1(A,b)
n=size(A,1);%仅查询 A 的第1个维度的长度。
x0 = zeros(n,1);  x1 = zeros(n,1); %初始化
M = 10;
for k = 1:M
    for j =1:n
        x1(j) = 0;
        for s = 1:n,if(s~=j),x1(j) =x1(j)-A(j,s)*x0(s);end;end
        x1(j) =(x1(j)+b(j))/A(j,j);
    end
    for j =1:n,x0(j) = x1(j);end
end


%雅可比迭代法2：采用矩阵的迭代表达式
function x1 = Jaconi_Iterion2(A,b)
n=size(A,1);
L = tril(A,-1);  U = triu(A,1);   D = A-L-U; %DLU分解
M = 10;
x0 = ones(n,1);%初始化
for k = 1:M
    x1 = D\(-(L+U)*x0+b);
    x0 =x1;
end

%高斯赛代尔迭代1：采用c语言思路
function x1 =Gauss_Seidel_Iteration1(A,b)
n=size(A,1);
x1 = zeros(n,1); %初始化
M = 10;
for k = 1:M
    for j =1:n
        x1(j) = 0;
        for s = 1:n,if(s~=j),x1(j) =x1(j)-A(j,s)*x1(s);end;end
        x1(j) =(x1(j)+b(j))/A(j,j);
    end
end

%高斯赛代尔迭代2：采用矩阵的迭代表达式
function x1 = Gauss_Seidel_Iteration2(A,b)
n=size(A,1);
L = tril(A,-1);  U = triu(A,1);   D = A-L-U; %DLU分解 %初始化
M = 10;
x0 = ones(n,1);
for k = 1:M
    x1 = (D+L)\(-U*x0+b);
    x0 = x1;   
end

%雅可比迭代过程的2-范数曲线显示，揭示收敛性
function Show_Convergence(A,b)
n=size(A,1);
L = tril(A,-1);  U = triu(A,1);   D = A-L-U; %DLU分解 %初始化
M = 10;
x0 = ones(n,1);
xx = zeros(1,M);
xx(1) = norm(x0); %返回向量 v 的欧几里德范数。此范数也称为 2-范数
figure(1024);
for k = 2:M
    x1 = D\(-(U+L)*x0+b);
    xx(k) = norm(x1);%返回向量 v 的欧几里德范数。此范数也称为 2-范数
    x0 = x1;   
    plot(1:k,xx(1:k),'o-r'),grid on ;drawnow;
end
xlabel('迭代次数');ylabel('解的2-范数');