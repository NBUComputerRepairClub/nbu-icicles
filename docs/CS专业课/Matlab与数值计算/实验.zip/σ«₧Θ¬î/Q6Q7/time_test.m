function time_test
clc;
tt1 = zeros(1,10);
tt2 = zeros(1,10);
tt3 = zeros(1,10);
tt4 = zeros(1,10);
tt5 = zeros(1,10); %%放每种算法的时间
for z =2:10 
A=rand(z,z);%随机z阶产生矩阵
b=rand(z,1);  
disp('**** 线性方程组迭代法测试，线性方程组为：');disp([A,b]);

tic;x1 = Jaconi_Iterion1(A,b); t1 = toc;
disp('雅可比迭代法一的解为：');disp(x1);
fprintf('耗费的时间为T=%8.6f(s)\n',t1);%计算运行时间
tt1(z) = t1;

tic;x2 = Jaconi_Iterion2(A,b); t2 = toc;
disp('雅可比迭代法二的解为：');disp(x2);
fprintf('耗费的时间为T=%8.6f(s)\n',t2);
tt2(z) = t2;

tic;x3 =Gauss_Seidel_Iteration1(A,b); t3 = toc;
disp('高斯迭代法一的解为：');disp(x3);
fprintf('耗费的时间为T=%8.6f(s)\n',t3);
tt3(z) = t3;

tic;x4 =Gauss_Seidel_Iteration2(A,b); t4 = toc;
disp('高斯迭代法二的解为：');disp(x4);
fprintf('耗费的时间为T=%8.6f(s)\n',t4);
tt4(z) = t4;

tic;x5 =Gauss_Elimination1(A,b); t5 = toc;
disp('高斯消元法的解为：');disp(x5);
fprintf('耗费的时间为T=%8.6f(s)\n',t5);
tt5(z) = t5;

%时间测试曲线

end
Show_time(tt1,tt2,tt3,tt4,tt5);

%雅可比迭代1：采用C语言思路
function x1 = Jaconi_Iterion1(A,b)
n=size(A,1);%仅查询 A 的第1个维度的长度。
x0 = zeros(n,1);  x1 = zeros(n,1); %初始化
M = 10;
for k = 1:M
    for j =1:n
        x1(j) = 0;
        for s = 1:n,if(s~=j),x1(j) =x1(j)-A(j,s)*x0(s);end;end
        x1(j) =(x1(j)+b(j))/A(j,j);
    end
    for j =1:n,x0(j) = x1(j);end
end


%雅可比迭代法2：采用矩阵的迭代表达式
function x1 = Jaconi_Iterion2(A,b)
n=size(A,1);
L = tril(A,-1);  U = triu(A,1);   D = A-L-U; %DLU分解
M = 10;
x0 = ones(n,1);%初始化
for k = 1:M
    x1 = D\(-(L+U)*x0+b);
    x0 =x1;
end

%高斯赛代尔迭代1：采用c语言思路
function x1 =Gauss_Seidel_Iteration1(A,b)
n=size(A,1);
x1 = zeros(n,1); %初始化
M = 10;
for k = 1:M
    for j =1:n
        x1(j) = 0;
        for s = 1:n,if(s~=j),x1(j) =x1(j)-A(j,s)*x1(s);end;end
        x1(j) =(x1(j)+b(j))/A(j,j);
    end
end

%高斯赛代尔迭代2：采用矩阵的迭代表达式
function x1 = Gauss_Seidel_Iteration2(A,b)
n=size(A,1);
L = tril(A,-1);  U = triu(A,1);   D = A-L-U; %DLU分解 %初始化
M = 10;
x0 = ones(n,1);
for k = 1:M
    x1 = (D+L)\(-U*x0+b);
    x0 = x1;   
end

%时间测试曲线
function Show_time(tt1,tt2,tt3,tt4,tt5);
hold on
for k = 2:10  
    plot(2:k,tt1(2:k),'o-r'),grid on ;drawnow;
    plot(2:k,tt2(2:k),'o-g'),grid on ;drawnow;
    plot(2:k,tt3(2:k),'o-b'),grid on ;drawnow;
    plot(2:k,tt4(2:k),'o-c'),grid on ;drawnow;
    plot(2:k,tt5(2:k),'o-m'),grid on ;drawnow;
    legend('雅可比迭代法一','雅可比迭代法二','高斯赛代尔迭代1','高斯赛代尔迭代2','高斯消元法');
end
xlabel('未知数个数');ylabel('运行时间');



%%
%%高斯消元法
function x =Gauss_Elimination1(A,b)
disp('消元前的增广矩阵');disp([A,b]);
[U,bb] = Gauss_Elimination(A,b);
disp('消元后的增广矩阵');disp([U,bb]);
x =Back_Substitution(U,bb);
disp('方程组的解');disp(x);
%A为系数矩阵，b为非齐次列向量
%U为消元后的上三角系数矩阵，bb为消元后非齐次列向量

function [U,bb] =Gauss_Elimination(A,b)
C = [A,b];
n =length(b);
for k =1 :(n-1)
    L = eye(n);
    for i = (k+1):n
        mik = C(i,k)/C(k,k); %mik 计算因子，变0，C（k,k）是主元
        L(i,k) = -1 * mik;   %记录所有每行的变化 ***
    end
    C = L*C;  %执行这个变化 ***
end
U = C(:,1:n);%取出消元后的上三角系数矩阵
bb =C(:,n+1);%取出消元后的非齐次列向量
%回代
function x =Back_Substitution(U,bb)
n = length(bb);
x = zeros(n,1);  %n*1的全零矩阵
x(n) = bb(n) /U(n,n);
for i = (n-1):-1:1
    x(i) = (bb(i)-U(i,(i+1):n)*x((i+1):n))/U(i,i);%迭代方程
end
%%
