function x1 = ddf_fun(x0,Theta)
x1 = cos(x0);