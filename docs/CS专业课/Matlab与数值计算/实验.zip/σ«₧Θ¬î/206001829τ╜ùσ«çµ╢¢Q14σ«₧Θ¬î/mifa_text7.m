A = [1 2 1;2 1 2; 3 4 2;]
x0  =rand(size(A,1),1);D = 1000;e0 = 0.001;
[Lamda,V1,D1] = mifa( x0,e0,D,A);
D1
Lamda
