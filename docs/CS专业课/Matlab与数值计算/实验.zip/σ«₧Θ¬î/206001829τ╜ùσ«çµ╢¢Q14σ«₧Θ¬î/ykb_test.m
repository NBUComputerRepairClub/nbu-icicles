function ykb_test
clc;
A =[ 1, 0.4, 0.4;
    0.4,1,0.8;
     0.4,0.8,1];
b = [1;2;3];
disp('**** 线性方程组迭代法测试，线性方程组为：');disp([A,b]);
L = tril(A,-1);  U = triu(A,1);   D = A-L-U; %DLU分解 tril()仅提取主对角线下方的元素。triu()

tic;x1 = Jaconi_Iterion1(A,b); t1 = toc;
disp('雅可比迭代法一的解为：');disp(x1);
disp(sprintf('耗费的时间为T=%8.6f(s)',t1));%计算运行时间

%雅可比迭代1：采用C语言思路
function x1 = Jaconi_Iterion1(A,b)
n=size(A,1);%仅查询 A 的第1个维度的长度。
x0 = zeros(n,1);  x1 = zeros(n,1); %初始化
M = 10;
for k = 1:M
    for j =1:n
        x1(j) = 0;
        for s = 1:n,if(s~=j),x1(j) =x1(j)-A(j,s)*x0(s);end;end
        x1(j) =(x1(j)+b(j))/A(j,j);
    end
    for j =1:n,x0(j) = x1(j);end
end

