% YATLAE实现幂法，在通用迭代法上进行更改
%输入参数：
%x0列向量，初始随机向量
%e0 数值，迭代退出的误差
%D数值，最大迭代次数
%Theta 参数向里，幂法中就是待求谱半径的矩阵A
% 输出参数：
%Iamda 数值，求解出来的谱半径值
%V1 列向量，归一化后的特征向量
%D1数值，实际迭代次数
function [Lamda, V1, D1] =mifa (x0, e0,D,Theta)
Lamda0 = 1;
k = 0;
while (1)
    x1 = Theta * x0;%计算x(k+1）
    Lamda = mean(x1./x0);%求谱半径
    %光只有迭代2次后才计耸误差
    if (k>1), e1=norm(Lamda-Lamda0) ; else e1 = e0+1; end
    if (e1<e0), break; end
    if (k>=D), break; end
    k= k+1;
    x0 = x1;
    Lamda0 = Lamda;
end
D1 = k;
V1 = x1/max(abs(x1)) ;