x0 = 1;D = 1000;e0 = 0.001;
[XX,D1]= ddf(x0,e0,D,[]);
D1
XX(D1)
cos(XX(D1))