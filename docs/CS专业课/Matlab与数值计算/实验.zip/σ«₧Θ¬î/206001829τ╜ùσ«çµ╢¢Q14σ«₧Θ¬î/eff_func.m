function y = eff_func(x)
y = x-cos(x);