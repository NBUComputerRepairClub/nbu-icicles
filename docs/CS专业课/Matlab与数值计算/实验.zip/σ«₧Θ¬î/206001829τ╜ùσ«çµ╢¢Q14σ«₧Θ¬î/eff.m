% MATLABE实现二分法，在通用迭代法上进行更改
% 输入参数：
%a,b 数值，初始区间端点
%e0 数值，最大允许误差
%D数值，最大迭代次数
%ff字符串，方程对应的函数名称
%输出参数：
%x0 数值，方程的解
% D1数值，实际迭代次数
function [x0,D1] =eff(a,b,e0,D,ff)
x0=Inf; D1=0;%非法解
ay = feval(ff, a);
by = feval(ff,b);
if (ay*by > 0), return; end %另不符合二分法前提条件，非法区间
while (1)
x0= (a+b)/2;y0 = feval (ff, x0);
if (y0*ay > 0), a = x0; ay = y0; else b = x0;by = y0; end
D1= D1+1;
if (D1>D), break; end
if (norm(a-b) < e0), break; end
end