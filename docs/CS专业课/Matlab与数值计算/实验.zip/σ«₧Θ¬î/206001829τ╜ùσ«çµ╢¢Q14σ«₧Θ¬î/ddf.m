%MATLAB买现通用选代法
% 输入参数：
%×0列向量，也可以是单个数值，看具体问题
%e0数值，迭代退出的误差
%D数值，最大选代次数。设确定最大选代次数的话，D=-1
%Theta 参数向量，可以有，也可以无，看具体问题。不需要额外参数的话，Theta=[]
%输出参数：
% xx 矩阵，每一列存放一个xk向量
%D1数值，实际迭代次数
function [XX, D1] = ddf (x0,e0, D, Theta)
N = length(x0);%获得 20 中的成员个数
if 0~=-1,XX=zeros (N,D);else XX = [];end %s初始化 双xx 矩阵
k = 0;
while (1)
    x1=ddf_fun(x0, Theta);%调用子函数计算x(k+1)
    XX (:, k+1) = x1;
    e1 = norm(x1-x0);%计算迭代误差
    if (e1<e0), break; end
    if (k>=D), break; end
    k = k+1;
    x0 = x1;
end
D1 = k;