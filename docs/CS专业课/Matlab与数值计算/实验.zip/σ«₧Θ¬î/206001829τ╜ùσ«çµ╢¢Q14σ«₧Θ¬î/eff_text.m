a = 0.5;b = 1;e0 =0.0001;D =1000;ff = 'eff_func';
[x0,D1] =eff(a,b,e0,D,ff);
D1
x0