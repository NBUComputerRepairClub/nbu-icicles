function EULER_Test
x0 = 0;h= 0.1;y0 =1;n=10;
[~,yy1] = Euler_Diff(x0,y0,h,n,1);%前向欧拉法
[~,yy2] = Euler_Diff(x0,y0,h,n,2);%后向欧拉法 
[~,yy4] = Euler_Diff(x0,exp(-0.1),h,n,4,y0);%中点欧拉法
[~,yy3] = Euler_Diff(x0,y0,h,n,3);%梯型欧拉法 
[xx,yy5] = Euler_Diff(x0,y0,h,n,5);%改进欧拉法 

yy0  =exp(xx); %假定的微分方程精确解，用于对比
figure ,plot(xx,[yy0,yy1,yy2,yy3,yy4,yy5]),grid on;
title('欧拉法求解结果');
legend('精确','前向','后向','梯型','中点','改进');


%前向欧拉法选代：y(k)=y(k-1）+ h*Fxy(x(k-1），y(k-1)）
function yk = do_Forward_Euler(xk_1,yk_1,h)
yk = yk_1+h*Fxy(xk_1,yk_1);


%后向欧拉法选代：y(k)=y(k-1）+ h*Fxy(x(k），y(k)）
function yk = do_Backward_Euler(xk,yk_1,h)
yk= yk_1; %先给一个初始值
for s= 1:100
    yk1 = yk_1+h*Fxy(xk,yk); %迭代靠近
    el =abs(yk1-yk);%迭代误差
    if(el<0.001),break;end %达到误差精度，则迭代退出
    yk = yk1;
end
yk = yk1;

%中点欧拉法选代：y(k） = y(k-2）十2*h*Fxy(x(k-1）， y(k-2)， y(k-1))
function yk = do_Midpoint_Euler(xk_1,yk_2,yk_1,h)
yk  = yk_2 + 2*h*Fxy(xk_1,yk_1);

% Fxy(z,y） 函数，不同的微分方程可以修改这里
function z = Fxy(x,y) %导数值
%z =2*y+5*x*y;
z=exp(x); %微分方程的精确解为：y=exp(x），用于测试求解精度

%假定常微分方程为：y' =Fxy(x, y), y(x0)= y0;
%输入参数：x0，h,n：x的求解点。从x0开始，每隔h求解一个对应的y值，共n个
% OP =3：歐拉法种类。OP=1，前向：0P=2，后向：
%OP=3，梯形：0P=4，中点：0P=5，改进欧拉法
function [xx,yy] = Euler_Diff(x0,y0,h,n,OP,y1)
if(nargin<5),OP =1;end %nargin 参数输入个数
xx = x0+(1:n)'*h;
yy = zeros(n,1);
for k = 1:n
    if(k == 1),xk_1=x0;yk_1=y0;
        else xk_1 = xx(k-1);yk_1 = yy(k-1);
    end
    xk = xx(k);
    switch(OP)
      case 1,yy(k) = do_Forward_Euler(xk_1,yk_1,h); %前向
      case 2,yy(k) = do_Backward_Euler(xk,yk_1,h); %后向
      case 3,yy(k) = do_Trapezoid_Euler(xk_1,xk,yk_1,h); %梯型
      case 4
            if(k == 1),yk_1= y1;yk_2 = y0;
            elseif(k==2),yk_1 = yy(1);yk_2 = y1;
            else yk_1 = yy(k-1);yk_2 =yy(k-2);
            end
            yy(k) = do_Midpoint_Euler(xk_1,yk_2,yk_1,h); %中点
     case 5,yy(k) = do_Modified_Euler(xk_1,xk,yk_1,h); %改进
     otherwise,break;
    end        
end

%梯型
function yk = do_Trapezoid_Euler(xk_1,xk,yk_1,h) %梯型 %存在隐式 迭代
yk= yk_1; %先给一个初始值
for s= 1:100
    yk1 =yk_1+(h/2)*(Fxy(xk_1,yk_1)+Fxy(xk,yk)); %迭代靠近
    el =abs(yk1-yk);%迭代误差
    if(el<0.001),break;end %达到误差精度，则迭代退出
    yk = yk1;
end
yk = yk1;

%改进
function yk = do_Modified_Euler(xk_1,xk,yk_1,h) %改进
yk1 = yk_1+h*Fxy(xk_1,yk_1);  %先预测yk
yk =yk_1+(h/2)*(Fxy(xk_1,yk_1)+Fxy(xk,yk1)); %校正