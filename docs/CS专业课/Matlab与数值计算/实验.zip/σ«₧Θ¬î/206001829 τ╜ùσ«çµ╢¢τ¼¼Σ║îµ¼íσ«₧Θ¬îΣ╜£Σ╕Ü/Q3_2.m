%%常态随机数
x = -4:0.1:4;
y0=randn(1,1000);
figure(1);
subplot(3,2,1);hist(y0,x);title('x');
y1=sin(randn(1,10000));
x = -2:0.01:2;
subplot(3,2,2);hist(y1,x);title('sin');
y2=cos(randn(1,10000));
subplot(3,2,3);hist(y2,x);title('cos');
y3=exp(randn(1,10000));
x = -1:0.1:20;
subplot(3,2,4);hist(y3,x);title('exp');
y4=power(randn(1,10000),2);
x = -1:0.1:20;
subplot(3,2,5);hist(y4,x);title('x^2');
%%均值随机数
figure(2);
x = -1:0.01:2;
y0=rand(1,10000);
subplot(3,2,1);hist(y0,x);title('x');
y1=sin(rand(1,10000));
x = -1:0.01:1;
subplot(3,2,2);hist(y1,x);title('sin');
y2=cos(rand(1,10000));
x = -1:0.01:1.5;
subplot(3,2,3);hist(y2,x);title('cos');
x = -1:0.1:4;
y3=exp(rand(1,10000));
subplot(3,2,4);hist(y3,x);title('exp');
x = -1:0.1:4;
y4=power(rand(1,20000),2);
subplot(3,2,5);hist(y4,x);title('x^2');

