
x = -4:0.1:4;
y1=randn(1,1000).*sqrt(0.2)+2;
y2=randn(1,1000);
subplot(2,1,1);hist(y1,x);title('正态分布随机数矩阵,均值2，方差0.1');
subplot(2,1,2);hist(y2,x);title('正态分布随机数矩阵,均值0，方差1');
