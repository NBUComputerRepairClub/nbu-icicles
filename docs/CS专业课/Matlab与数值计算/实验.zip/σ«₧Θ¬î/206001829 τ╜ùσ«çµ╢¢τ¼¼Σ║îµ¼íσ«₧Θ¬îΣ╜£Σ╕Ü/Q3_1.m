x = [76,79,91,0,19,41,1;76,61,93,81,27,46,83;95,7,73,5,19,44,20;95,7,73,89,20,74,52;95,7,40,35,60,93,67;95,45,92,41,13,1,84;];
disp(x);
disp("列最大值：");
disp(max(x,[],1));
disp("列最小值：");
disp(min(x,[],1));
disp("列均值：");
disp(mean(x,1));
disp("列方差：");
disp(std(x,0,1));
disp("列中位数：");
disp(median(x,1));


disp("行最大值：");
disp(max(x,[],2));
disp("行最小值：");
disp(min(x,[],2));
disp("行均值：");
disp(mean(x,2));
disp("行方差：");
disp(std(x,0,2));
disp("行中位数：");
disp(median(x,2));
disp("排序按[1,2,3]：");
disp(sortrows(x,[1,2,3]));
disp("列和：");
disp(sum(x,1));
disp("行和：");
disp(sum(x,2));
disp("所有元素和：");
disp(sum(x,'all'));


