function Grade = letter_grade(Score)
    if Score <60 
        Grade = 'F';
    elseif Score<70
        Grade = 'D';
        elseif Score<80
             Grade = 'C';
             elseif Score<90
                 Grade = 'B';
                 elseif Score<=100
                 Grade = 'A';
    else
                        Grade = '成绩无效';
    end 
end
