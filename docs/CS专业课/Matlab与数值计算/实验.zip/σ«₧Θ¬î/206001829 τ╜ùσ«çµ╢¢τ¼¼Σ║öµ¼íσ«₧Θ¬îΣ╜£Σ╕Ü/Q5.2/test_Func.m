function y =test_Func(x)
y =x- cos(x);%假定的非线性方程 