function [x,hasroot] = ddf_fxxfc(x0,e)
hasroot = 0;
k = 0;
while k<1000
    x = func0(x0);
    if abs(x- x0)<e %解的最大误差
        hasroot =1;break;  %解的合法性
    end
    k =k+1;
    x0 =x;
end

