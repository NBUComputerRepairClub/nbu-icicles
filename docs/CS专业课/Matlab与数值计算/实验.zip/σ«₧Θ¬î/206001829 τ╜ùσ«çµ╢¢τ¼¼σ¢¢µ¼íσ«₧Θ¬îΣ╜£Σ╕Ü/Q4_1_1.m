x = linspace(0,1,100);
y = sin(2*pi*x);
plot(x,y)