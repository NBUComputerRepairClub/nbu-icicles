x = linspace(0,1,100);
y =sin(2*pi*2*x);
z = cos(2*pi*2*x);
plot(x,y,x,z,'r--'),grid on;
title('两条曲线');
xlabel('x轴');ylabel('y轴');
legend('sin曲线','cos曲线');