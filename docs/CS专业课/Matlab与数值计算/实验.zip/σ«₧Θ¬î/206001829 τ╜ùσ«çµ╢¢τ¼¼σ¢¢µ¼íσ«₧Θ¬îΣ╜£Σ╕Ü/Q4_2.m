t = 0:0.1:100;
x =sin(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
y =cos(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
subplot(221),plot(x,y),title('t =0.1');

t = 0:0.01:100;
x =sin(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
y =cos(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
subplot(222),plot(x,y),title('t =0.01');

t = 0:0.5:100;
x =sin(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
y =cos(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
subplot(223),plot(x,y),title('t =0.5');

t = 0:1/1000:100;
x =sin(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
y =cos(t).*(exp(cos(t))-2*cos(4*t)-(sin(t/12)).^5);
subplot(224),plot(x,y),title('t =1/1000');