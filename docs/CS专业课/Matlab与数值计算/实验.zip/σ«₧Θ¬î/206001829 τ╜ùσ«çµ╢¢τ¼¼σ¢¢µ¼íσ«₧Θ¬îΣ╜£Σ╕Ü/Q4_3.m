t = linspace(0,10*pi,1000);
r =exp(sin(t))-2*cos(4*t)-(sin((2*t-pi)/24)).^5;
polarplot(t,r),title('t =0.01');legend('线');