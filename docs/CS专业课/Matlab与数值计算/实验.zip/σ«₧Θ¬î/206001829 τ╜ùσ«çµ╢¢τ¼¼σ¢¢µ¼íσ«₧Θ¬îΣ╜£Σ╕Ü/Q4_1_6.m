figure
[x,y] =meshgrid(-2:.2:2);
z =x.*exp(-x.^2-y.^2);
[DX,DY] = gradient(z,.2,.2);
contour(x,y,z);
hold on;
quiver(x,y,DX,DY);
colormap hsv;
hold off;