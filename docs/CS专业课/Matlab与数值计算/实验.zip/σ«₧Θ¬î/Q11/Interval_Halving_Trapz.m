%区间逐步对分的复化梯形求积
function [I,n]= Interval_Halving_Trapz(a,b)
err  = 0.0001; %误差精度
n = 1;
D = 100;  %最大迭代次数
i= 0; %初始迭代次数
T1 = (b-a)*(g(a)+g(b))/2;  
while (true)
    n  = 2*n; %区间个数增加一倍二区间宽度诚少一半
    x =linspace(a,b,n+1); %把区间分割成n等分
    h = x(2)-x(1);          %区间宽度
    y = g(x);               %对被积函数进行采样
    T2  = (h/2)*(y(1)+2*sum(y(2:n))+y(n+1));  %复化梯形公式
    e0  = abs(T2-T1);
    if(e0<err),break;end
    i= i+1;if(i>D),break;end
    T1 = T2;
end
I = T2;

