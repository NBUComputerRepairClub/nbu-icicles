function y  = g(x)
y  = sin(x);