y1 = [0,1,-3,2,1,2];
y2 = [3,0,2,1,0,7];

pa =y1+y2
pb =y1-y2
pc =conv(y1,y2)
[S,R] =deconv(y1,y2)
