x=pi/3;
disp("cos:");
fprintf('%.8f\n',cos(x))

disp("P4:");
p= [1/factorial(4),0,-1/factorial(2),0,1];
fprintf('%.8f\n', polyval(p,x))
disp("P6:");
p= [-1/factorial(6),0,1/factorial(4),0,-1/factorial(2),0,1];
fprintf('%.8f\n', polyval(p,x))
disp("P8:");
p= [1/factorial(8),0,-1/factorial(6),0,1/factorial(4),0,-1/factorial(2),0,1];
fprintf('%.8f\n', polyval(p,x))

disp("P50:");
a= [];
for i = 50:-1:1 %循环生成要求的矩阵
    if(mod(i,2) == 0)
        a= [a,(-1).^(i/2)/factorial(i)];%添加元素
    else
        a= [a,0];%奇数位加0
    end   
end
a=[a,1];
fprintf('%.20f\n', polyval(a,x))

