x = [-2;-1;1;3;5;];
p = poly(x);
v =polyval(p,0)
x0 = -1/v
x= [x;x0];
y = poly(x)%结果
