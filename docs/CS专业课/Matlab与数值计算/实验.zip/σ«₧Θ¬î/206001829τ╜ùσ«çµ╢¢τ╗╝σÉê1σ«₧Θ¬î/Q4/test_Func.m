function y =test_Func(x)
y =x.^4+3*x.^3+20*x.^2+44*x+54;%假定的非线性方程 