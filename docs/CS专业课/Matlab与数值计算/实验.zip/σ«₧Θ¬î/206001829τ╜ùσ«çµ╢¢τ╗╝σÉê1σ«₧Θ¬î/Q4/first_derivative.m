%求导
function dF = first_derivative(Fname,x0,err0) 
if(x0 == 0)
    dx = 1.0e-2;
else
    dx = 0.1*x0;
end
dF0 = inf ;
k =1;
while(k<1000)
    f1 = Fname(x0-dx); f2 = Fname(x0+dx);
    dF1 = (f2-f1)/2/dx; 
    if (abs(dF0-dF1)<err0) break;end%err0 精度
    dF0 = dF1;
    dx = dx/2;
    k=k+1;
end
dF = dF1;
