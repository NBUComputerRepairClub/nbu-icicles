function x = fxxfc_newton(x0)
for k =1:1000
    x =x0 -test_Func(x0)/first_derivative(@test_Func,x0,0.01);
    if abs(x- x0)<0.0001  %精度
        break;
    else
        x0 =x;
    end  
end