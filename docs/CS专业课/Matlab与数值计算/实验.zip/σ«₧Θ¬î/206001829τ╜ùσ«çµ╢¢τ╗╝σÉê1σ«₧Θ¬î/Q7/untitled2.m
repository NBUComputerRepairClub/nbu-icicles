A = [2,-1,1;
    -1,-2,3;
    1,3,1;];
B = [1 2 3;
     2 1 4;
     5 2 1;];
A1 = cond(A,1) 
A2 = cond(A,2) 
Ainf = cond(A,inf) 
B1 = cond(B,1) 
B2 = cond(B,2) 
Binf = cond(B,inf) 