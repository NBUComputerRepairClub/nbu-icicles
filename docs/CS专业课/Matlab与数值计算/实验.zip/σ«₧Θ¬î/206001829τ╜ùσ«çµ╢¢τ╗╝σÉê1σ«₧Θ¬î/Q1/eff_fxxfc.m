function [x,hasroot] = eff_fxxfc(a,b,eps1) %eps1 求解的精度
hasroot =0;
for k = 1 :1000
    x = (a+b)/2;
    
    if(abs(func0(x))<eps1)
        hasroot = 1;break;
    end
    if(func0(a)*func0(x)< 0) 
        b = x;
    else
        a =x;
    end    
end


