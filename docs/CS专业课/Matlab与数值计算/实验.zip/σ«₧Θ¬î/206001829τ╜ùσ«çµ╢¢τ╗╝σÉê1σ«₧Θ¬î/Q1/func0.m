function y =func0(x)
y =x.^2-x-1;%假定的非线性方程