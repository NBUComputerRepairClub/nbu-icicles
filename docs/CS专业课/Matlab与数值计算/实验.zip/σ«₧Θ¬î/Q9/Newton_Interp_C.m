%牛顿法一C语言思路
%已知n+1组数据<xi,yi>,i=1...(n+1)，求xx对应的yy插值
function yy=Newton_Interp_C(xi,yi,x0)
%Newton基本插值公式
%x为向量，全部的插值节点
%y为向量，差值节点处的函数值
%xi为标量，是自变量
%yi为xi出的函数估计值
n=length(xi);
m=length(yi);
if n~=m
    error('The lengths of X ang Y must be equal!');
    return;
end
%计算均差表Y
Y=zeros(n);
Y(:,1)=yi';
for k=1:n-1
    for i=1:n-k
        if abs(xi(i+k)-xi(i))<eps
            error('the DATA is error!');
            return;
        end
        Y(i,k+1)=(Y(i+1,k)-Y(i,k))/(xi(i+k)-xi(i)); %差商
    end
end
%计算牛顿插值公式
yy=0;
for i=1:n
    z=1;
    for k=1:i-1
        z=z.*(x0-xi(k));
    end
    yy=yy+Y(1,i)*z;
end