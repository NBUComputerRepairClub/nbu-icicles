clear all 
clc
xi = 0:0.1 :pi; yi =sin(xi);%生成插值节点
xx=0.15:0.2:pi;  % 待插值点。
yy=Newton_Interp_C(xi,yi,xx);% yy即为待插值点的函数值。
%显示插值效果
figure(1),plot(xi,yi,xx,yy,'*r'),grid on;
legend('插值曲线（sin','插值结果');xlabel('x');