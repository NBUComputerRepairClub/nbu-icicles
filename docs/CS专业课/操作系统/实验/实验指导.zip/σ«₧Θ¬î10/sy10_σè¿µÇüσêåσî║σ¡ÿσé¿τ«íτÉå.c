#include "stdio.h"
#define N 5
struct freearea
{
	int startaddr;//内存块开始地址
	int size;  //大小
	int state;  //是否空闲，1为空闲，0被占用
} freeblock[N] = {{20, 20, 1}, {80, 50, 1}, {150, 100, 1}, {300, 30, 0}, {600, 100, 1}};
/* 定义分配主存空间函数 alloc() */
int alloc(int applyarea)
{
	int i, tag = 0;//tag，0表示未找到空闲且空间足够的内存块，1表示找到
	for (i = 0; i < N; i++)
	{
		if (freeblock[i].state == 1 && freeblock[i].size > applyarea)//空闲内存块且大小>申请大小
		{
			freeblock[i].startaddr += applyarea;//空闲块开始地址+=applyarea
			freeblock[i].size -= applyarea;//分配内存空间给申请的
			tag = 1;
			return freeblock[i].startaddr - applyarea;//空闲块地址首地址改变，-applyarea
		}
		else if (freeblock[i].state == 1 && freeblock[i].size == applyarea)
		{
			freeblock[i].state = 0;//全部分配完毕，，状态置为占用
			tag = 1;
			return freeblock[i].startaddr;
		}
	}
	if (tag == 0) //未成功分配
		return -1;
}
/* 定义主存空间回收函数 setfree() */
void setfree()
{
	int s, l, tag1 = 0, tag2 = 0, tag3 = 0, i, j;
	printf("\nInput free area startaddress: ");//模拟释放内存空间或者空闲块合并
	scanf("%d", &s); //空闲区开始地址
	printf("\n Input free area size: ");
	scanf("%d", &l); //空闲区长度
	for (i = 0; i < N; i++)//查看高地址有无相邻的空闲块
	{
		if (freeblock[i].startaddr == s + l && freeblock[i].state == 1)//存在空闲的内存块，且新空闲块与旧空闲内存块相邻，startaddr == s + l
		{
			l += freeblock[i].size;//2块合并，低地址作为开始地址，大小为2者和
			tag1 = 1;
			for (j = 0; j < N; j++)//查看低地址有无相邻的空闲块
			{
				if (freeblock[j].startaddr + freeblock[j].size == s && freeblock[j].state == 1)//存在空闲的内存块，且新空闲块与旧空闲内存块相邻，freeblock[j].startaddr + freeblock[j].size == s
				{
					freeblock[i].state = 0;//2块合并，低地址作为开始地址，大小为2者和
					freeblock[j].size += l;
					tag2 = 1;
					break;
				}
			}
			if (tag2 == 0) //向上合并后，更改上合并块的开始地址和大小
			{
				freeblock[i].startaddr = s; //开辟新的空闲块
					freeblock[i].size = l;
				break;
			}
		}
	}
	if (tag1 == 0)//向下合并过
	{
		for (i = 0; i < N; i++)//判断是否还存在空闲区与输入开始地址相邻
		{
			if (freeblock[i].startaddr + freeblock[i].size == s && freeblock[i].state == 1)//低地址存在相邻空闲区
			{
				freeblock[i].size += l;
				tag3 = 1; //标志再次向上合并
				break;
			}
		}
		if (tag3 == 0)
			for (j = 0; j < N; j++)
				if (freeblock[j].state == 0) //在状态为不空闲的记录，记录该空闲块信息
				{
					freeblock[j].startaddr = s;
					freeblock[j].size = l;
					freeblock[j].state = 1;
					break;
				}
	}
}
void adjust()
{
	int i, j;
	struct freearea middata;
	for (i = 1; i < N; i++) //将空闲区按始地址顺序在表中排列
		for (j = 0; j < N - i; j++)
			if (freeblock[j].startaddr > freeblock[j + 1].startaddr) //排序
			{
				middata = freeblock[j];//交换，冒泡排序
				freeblock[j] = freeblock[j + 1];
				freeblock[j + 1] = middata;
			}
	for (i = 1; i < N; i++) //将空表目放在表后面
		for (j = 0; j < N - i; j++)
			if (freeblock[j].state == 0 && freeblock[j + 1].state == 1)
			{
				middata = freeblock[j];
				freeblock[j] = freeblock[j + 1];
				freeblock[j + 1] = middata;
			}
}
void print()//输出空闲区表信息
{
	int i;
	printf(" |-----------------------------------|\n");
	printf(" | startaddr size state |\n");
	for (i = 0; i < N; i++)
		printf(" | %4d %4d %4d |\n",
			   freeblock[i].startaddr, freeblock[i].size, freeblock[i].state);
}
int main()
{
	int applyarea, start;
	long i;
	char end;
	printf("\nIs there any job request memory? (y or n): ");
	while ((end = getchar()) == 'y')
	{
		printf("At first the free memory is this:\n");
		adjust();//空闲区按始地址顺序在表中排列，空表目放在表后面
		print();//输出空闲区表
		printf("Input request memory size: ");
		scanf("%d", &applyarea);
		start = alloc(applyarea); //分配请求空间
		if (start == -1)
			printf("There is no fit memory.please wait!!\n");
		else
		{
			printf("Job's memory start address is: %d\n", start);
			printf(" Job size is: %d\n", applyarea);
			printf("After allocation the free memory is this:\n");
			adjust();//空闲区按始地址顺序在表中排列，空表目放在表后面
			print();//输出空闲区表
			printf("Job is running.\n");
			for (i = 0; i < 100000; i++)
				;
			printf("Job is terminated.\n");
		}
		setfree();//合并空闲区块
		adjust();//空闲区按始地址顺序在表中排列，空表目放在表后面
		print();//输出空闲区表
		printf("Is there any job that is waiting? (y or n): ");
		end = getchar();
	}
}