// #include <time.h> /* 在 windows 系统中，增加此头文件 */
#define TRUE 1
#define FALSE 0
#define INVALID -1
#define NULL 0
#define RAND_MAX 32767 / 32767 / 2 /* 在windows系统中改为 32767 */
#define total_instruction 320      /*指令流长*/
#define total_vp 32                /*虚页长数*/
#define clear_period 50            /*清0周期*/
typedef struct                     /*页面结构*/
{
	int pn, pfn, counter, time; //页号，页面框架号，计数器，时间
} pl_type;                      //页表项
pl_type pl[total_vp];           /*页面结构数组*/
struct pfc_struct
{ /*页面控制结构*/
	int pn, pfn;
	struct pfc_struct *next;
}; //页表的链式存储方式
typedef struct pfc_struct pfc_type;
pfc_type pfc[total_vp], *freepf_head, *busypf_head, *busypf_tail;
int diseffect, a[total_instruction]; //页面失效次数，指令流数据组
int page[total_instruction], offset[total_instruction];
//每条指令所属的页号；每页装入10条指令后取模运算页号偏移值
int initialize(int);
int FIFO(int);
int LRU(int);
int LFU(int);
int NUR(int);
int OPT(int);
int main()
{
	int s, i, j;
	srand(10 * getpid());                      /* 由于每次运行时进程号不同，故可用来作为初始化
						  随机数队列的“种子” . 在windows系统中改为 srand(time(NULL)); */
	s = (float)319 * rand() / RAND_MAX + 1;    //
	for (i = 0; i < total_instruction; i += 4) /*产生指令队列*/
	{
		if (s < 0 || s > 319)
		{
			printf("When i==%d,Error,s==%d\n", i, s);
			exit(0);
		}
		a[i] = s;                                   /*任选一指令访问点m*/
		a[i + 1] = a[i] + 1;                        /*顺序执行一条指令*/
		a[i + 2] = (float)a[i] * rand() / RAND_MAX; /*执行前地址指令m' */
		a[i + 3] = a[i + 2] + 1;                    /*顺序执行一条指令*/
		s = (float)(318 - a[i + 2]) * rand() / RAND_MAX + a[i + 2] + 2;
		if ((a[i + 2] > 318) || (s > 319))
			printf("a[%d+2],a number which is :%d and s==%d\n", i, a[i + 2], s);
	}
	for (i = 0; i < total_instruction; i++) /*将指令序列变换成页地址流*/
	{
		page[i] = a[i] / 10;
		offset[i] = a[i] % 10;
	}
	for (i = 4; i <= 32; i++) /*用户内存工作区从4个页面到32个页面*/
	{
		printf("---%2d page frames---\n", i);
		FIFO(i);
		LRU(i);
		LFU(i);
		NUR(i);
		OPT(i);
	}
	return 0;
}
int initialize(total_pf) /*初始化相关数据结构*/
int total_pf;            //分配给进程的物理块数 /*用户进程的内存页面数*/
{
	int i;
	diseffect = 0;
	for (i = 0; i < total_vp; i++) //有32页，对每页进行循环，初始化页表
	{
		pl[i].pn = i;        //页号
		pl[i].pfn = INVALID; //物理块号 /*置页面控制结构中的页号，页面为空*/
		pl[i].counter = 0;
		pl[i].time = -1; /*页面控制结构中的访问次数为0，时间为-1*/
	}
	for (i = 0; i < total_pf - 1; i++) // total_pf,物理块数
	{
		pfc[i].next = &pfc[i + 1];
		pfc[i].pfn = i;
	} /*建立pfc[i-1]和pfc[i]之间的链接*/ //把可用的几个物理块前后链接起来
	pfc[total_pf - 1].next = NULL;       //最后一个物理块要单独处理
	pfc[total_pf - 1].pfn = total_pf - 1;
	freepf_head = &pfc[0]; /*空页面队列的头指针为pfc[0]*/
	//开始的时候所有的物理块都是空的
	return 0;
}
int FIFO(total_pf) /*先进先出算法*/
int total_pf;      /*用户进程的内存页面数*/
{
	int i, j;
	pfc_type *p;
	initialize(total_pf);             /*初始化相关页面控制用数据结构*/
	busypf_head = busypf_tail = NULL; /*忙页面队列头，队列尾链接*/
	//最初，所有物理块都
	//未被占用，因此忙队列为空
	for (i = 0; i < total_instruction; i++) //对所有指令进行循环，模式顺序执行所有指令
	{
		if (pl[page[i]].pfn == INVALID) /*页面失效*/
			//, 所有页表项还没有分配物理块号
			{                                           //如果该指令对应的页还没有分配物理块的话，下面将调入内存
				diseffect += 1;                         /*失效次数*/
				if (freepf_head == NULL) /*无空闲页面*/ //空闲页面指的是空闲物理块？
				{
					p = busypf_head->next;             //忙内存块
					pl[busypf_head->pn].pfn = INVALID; //换出去，则以为着没有分配
						freepf_head = busypf_head; /*释放忙页面队列的第一个页面*/
					//因此空了一个块了
					freepf_head->next = NULL; //只释放一个页面，故只有一个元素
					busypf_head = p;          //忙队列头指针向后移动一个位置
				}
				p = freepf_head->next; /*按FIFO方式调新页面入内存页面*/
				freepf_head->next = NULL;
				freepf_head->pn = page[i];
				pl[page[i]].pfn = freepf_head->pfn;
				if (busypf_tail == NULL) //被占用一个了，所以忙队列不为空了
					busypf_head = busypf_tail = freepf_head;
				else
				{
					busypf_tail->next = freepf_head; /*free页面减少一个*/
					busypf_tail = freepf_head;
				}
				freepf_head = p;
			}
	}
	printf("FIFO:%6.4f\n", 1 - (float)diseffect / 320);
	return 0;
}
int LRU(total_pf) /*最近最久未使用算法*/
int total_pf;
{
	int min, minj, i, j, present_time;
	initialize(total_pf);
	present_time = 0;
	for (i = 0; i < total_instruction; i++)
	{
		if (pl[page[i]].pfn == INVALID) /*页面失效*/
		{
			diseffect++;
			if (freepf_head == NULL) /*无空闲页面*/
			{
				min = 32767;
				for (j = 0; j < total_vp; j++) /*找出time的最小值*/
					if (min > pl[j].time && pl[j].pfn != INVALID)
					{
						min = pl[j].time;
						minj = j;
					}
				freepf_head = &pfc[pl[minj].pfn]; //腾出一个单元
				pl[minj].pfn = INVALID;
				pl[minj].time = -1;
					freepf_head->next = NULL;
			}
			pl[page[i]].pfn = freepf_head->pfn; //有空闲页面,改为有效
			pl[page[i]].time = present_time;
			freepf_head = freepf_head->next; //减少一个free 页面
		}
		else
			pl[page[i]].time = present_time; //命中则增加该单元的访问次数
		present_time++;
	}
	printf("LRU:%6.4f\n", 1 - (float)diseffect / 320);
	return 0;
}
int NUR(total_pf) /*最近未使用算法*/
int total_pf;
{
	int i, j, dp, cont_flag, old_dp;
	pfc_type *t;
	initialize(total_pf);
	dp = 0;
	for (i = 0; i < total_instruction; i++)
	{
		if (pl[page[i]].pfn == INVALID) /*页面失效*/
		{
			diseffect++;
			if (freepf_head == NULL) /*无空闲页面*/
			{
				cont_flag = TRUE;
				old_dp = dp;
				while (cont_flag)
					if (pl[dp].counter == 0 && pl[dp].pfn != INVALID)
						cont_flag = FALSE;
					else
					{
						dp++;
						if (dp == total_vp)
							dp = 0;
						if (dp == old_dp)
							for (j = 0; j < total_vp; j++)
								pl[j].counter = 0;
					}
				freepf_head = &pfc[pl[dp].pfn];
				pl[dp].pfn = INVALID;
				freepf_head->next = NULL;
			}
			pl[page[i]].pfn = freepf_head->pfn;
			freepf_head = freepf_head->next;
		}
		else
			pl[page[i]].counter = 1;
			if (i % clear_period == 0) for (j = 0; j < total_vp; j++)
				pl[j]
					.counter = 0;
	}
	printf("NUR:%6.4f\n", 1 - (float)diseffect / 320);
	return 0;
}
int OPT(total_pf) /*最佳置换算法*/
int total_pf;
{
	int i, j, max, maxpage, d, dist[total_vp];
	pfc_type *t;
	initialize(total_pf);
	for (i = 0; i < total_instruction; i++)
	{ // printf("In OPT for 1,i=%d\n",i);
		// i=86;i=176;206;250;220,221;192,193,194;258;274,275,276,277,278;
		if (pl[page[i]].pfn == INVALID) /*页面失效*/
		{
			diseffect++;
			if (freepf_head == NULL) /*无空闲页面*/
			{
				for (j = 0; j < total_vp; j++)
					if (pl[j].pfn != INVALID)
						dist[j] = 32767; /* 最大"距离" */
					else
						dist[j] = 0;
				d = 1;
				for (j = i + 1; j < total_instruction; j++)
				{
					if (pl[page[j]].pfn != INVALID)
						dist[page[j]] = d;
					d++;
				}
				max = -1;
				for (j = 0; j < total_vp; j++)
					if (max < dist[j])
					{
						max = dist[j];
						maxpage = j;
					}
				freepf_head = &pfc[pl[maxpage].pfn];
				freepf_head->next = NULL;
				pl[maxpage].pfn = INVALID;
			}
			pl[page[i]].pfn = freepf_head->pfn;
			freepf_head = freepf_head->next;
		}
	}
	printf("OPT:%6.4f\n", 1 - (float)diseffect / 320);
		return 0;
}
int LFU(total_pf) /*最不经常使用置换法*/
int total_pf;
{
	int i, j, min, minpage;
	pfc_type *t;
	initialize(total_pf);
	for (i = 0; i < total_instruction; i++)
	{
		if (pl[page[i]].pfn == INVALID) /*页面失效*/
		{
			diseffect++;
			if (freepf_head == NULL) /*无空闲页面*/
			{
				min = 32767;
				for (j = 0; j < total_vp; j++)
				{
					if (min > pl[j].counter && pl[j].pfn != INVALID)
					{
						min = pl[j].counter;
						minpage = j;
					}
					pl[j].counter = 0;
				}
				freepf_head = &pfc[pl[minpage].pfn];
				pl[minpage].pfn = INVALID;
				freepf_head->next = NULL;
			}
			pl[page[i]].pfn = freepf_head->pfn; //有空闲页面,改为有效
			pl[page[i]].counter++;
			freepf_head = freepf_head->next; //减少一个free 页面
		}
		else
			pl[page[i]].counter++;
	}
	printf("LFU:%6.4f\n", 1 - (float)diseffect / 320);
	return 0;
}