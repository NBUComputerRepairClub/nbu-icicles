#include <stdio.h>
#include <signal.h>
#include <unistd.h>
void waiting(), stop();
int wait_mark;
int main()
{
    int p1, p2, stdout;
    while ((p1 = fork()) == -1)
        ; /*创建子进程 p1*/
    if (p1 > 0)
    {
        while ((p2 = fork()) == -1)
            ; /*创建子进程 p2*/
        if (p2 > 0)
        {
            wait_mark = 1;
            signal(SIGINT, stop); /*接收到^c 信号，转 stop*/
            waiting();            //如无按键将等待
            kill(p1, 16);         /*向 p1 发软中断信号 16*/
            kill(p2, 17);         /*向 p2 发软中断信号 17*/
            wait(0);              /*同步等待子进程结束*/
            wait(0);
            printf("Parent process is killed!\n");
            exit(0); //退出进程
        }
        else
        {
            wait_mark = 1;
            signal(SIGINT, SIG_IGN); /*设置信号函数处理方式，当收到键
            盘发送键盘中断（如break键被按下）信号时将会忽略此信号。*/
            signal(17, stop);        /*接收到软中断信号 17，转 stop 接受父进程发送信
                    号*/
            waiting();
            lockf(stdout, 1, 0);
            printf("Child process 2 is killed by parent!\n");
            lockf(stdout, 0, 0);
            exit(0);
        }
    }
    else
    {
        wait_mark = 1;
        signal(16, stop); /*接收到软中断信号 16，转 stop*/
        waiting();
        lockf(stdout, 1, 0);
        printf("Child process 1 is killed by parent!\n");
        lockf(stdout, 0, 0);
        exit(0);
    }
}
void waiting()
{
    while (wait_mark != 0)
        ; //通过循环使子进程停止
}
void stop()
{
    wait_mark = 0; //使子进程继续运行
}