#include <stdio.h>
#include <stdlib.h>
#include <time.h>
struct pcb
{
    int id; // 编号
    int status; //状态
    int firstaddr;  //首地址
    int length;  //长度
    int outbufword;  //输出井
} * PCB[3];
FILE *f;
struct req //输出请求块
{
    int reqname; //请求输出的用户进程名
    int length;  //要输出信息的长度
    int addr;    //输出信息在输出井中的位置
} reqblock[10];
int buffer[2][100]; //为两个用户进程设置两个输出井，每个可存放 100 个信息
int c3 = 10; 
int l1 = 1, l2 = 1;
int head = 0, tail = 0;//
int t1, t2;
void request(int i) //处理进程
{
    int j, length = 0, m;
    struct req *run;
    if ((tail - head) == 10) //如果该用户输出井数=10
    {
        PCB[i - 1]->status = 1; //对应输出井状态表示满
        return;
    }
    if (i == 1) //处理对应用户一个进程
        t1--;
    else
        t2--;
    run = &reqblock[tail % 10]; //run=一个输出请求块
    run->reqname = i; 
    run->length = 0;
    if (tail == 0) //最后一个请求块，开始地址为0
        run->addr = 0;
    else
    {
        int index = (tail - 1) % 10; //计算该请求块开始地址
        run->addr = reqblock[index].addr + reqblock[index].length;
    }
    for (m = 0; m < 100; m++)
    {
        if (buffer[i - 1][m] == 0) //找到缓冲区0的位置，作为开始地址
        {
            run->addr = m;
            break;
        }
    }
    printf("process %d: ", i); //输出
    while (1)
    {
        j = rand() % 10;
        if (j == 0)
        {
            run->length = length; //？？
            break;
        }
        buffer[i - 1][run->addr + length] = j;
        printf("%d ", j);
        length++;
    }
    printf("\n");
    PCB[i - 1]->length += length;
    length = 0;
    if (PCB[2]->status == 2)
        PCB[2]->status = 0;
    tail++;
}
void spooling()
{
    int i, j;
    struct req *run;
    run = &reqblock[head % 10];
    printf("PID %d: ", run->reqname);  //spooling
    fprintf(f, "PID %d:", run->reqname);
    for (i = 0; i < run->length; i++)
    {
        printf("%d ", buffer[run->reqname - 1][run->addr + i]);
        fprintf(f, "%d ", buffer[run->reqname - 1][run->addr + i]);
    }
    printf("\n");
    fprintf(f, "\n");
    head++;
    for (j = 0; j < 2; j++)
        if (PCB[j]->status == 1)
            PCB[j]->status = 0;
}
int main()
{
    int i, n; 
    f = fopen("result.txt", "w");//创建并打开文件
    for (i = 0; i < 2; i++)
        for (n = 0; n < 100; n++) //初始化数组为0
            buffer[i][n] = 0;
    for (i = 0; i < 3; i++)
    {
        struct pcb *temppcb; //pcb块指针
        temppcb = (struct pcb *)malloc(sizeof(struct pcb));//产生实例，并初始化
        temppcb->id = i;
        temppcb->status = 0;
        temppcb->firstaddr = 0;
        temppcb->length = 0;
        temppcb->outbufword = 1; //缓冲区编号
        PCB[i] = temppcb; 
    }
    printf("How many work do process 1 want to do? ");
    fprintf(f, "How many work do process 1 want to do? ");
    scanf("%d", &t1); //t1的进程数
    fprintf(f, "%d\n", t1);
    printf("How many work do process 2 want to do? ");
    fprintf(f, "How many work do process 2 want to do? ");
    scanf("%d", &t2); //t2的进程数
    fprintf(f, "%d\n", t2);
    srand((unsigned)time(NULL));
    while (1)
    {
        i = rand() % 100; //随机数
        if (i <= 45)
        {
            if ((PCB[0]->status == 0) && (t1 > 0))
                request(1); //处理第一个用户进程输出
        }
        else if (i <= 90)
        {
            if ((PCB[1]->status == 0) && (t2 > 0))
                request(2);//处理第2个用户进程输出
        }
        else if (head == tail) 
            PCB[2]->status = 2; //输出井空
        else
            spooling();// SPOOLING 进程执行输出
        if ((t1 == 0) && (t2 == 0) && (head == tail)) //所有进程处理完毕
            break;
    }
    for (i = 0; i < 3; i++)
    {
        free(PCB[i]); //释放3个pcb块
        PCB[i] = NULL;
    }
    fclose(f);
    return 0;
}