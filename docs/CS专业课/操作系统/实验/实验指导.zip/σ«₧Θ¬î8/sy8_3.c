#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#define SHMKEY 70
#define SEMKEY 80
#define K 1024
typedef int arr[16][256];
int shmid;
int semid;
int main()
{
		int i, in = 0;
		char *addr;
		arr *arrp;
		struct sembuf ops1 = {1, -1, SEM_UNDO}, //ops1 表示结构组中成员个数，>0s申请资源，<0释放资源，0改变信号量的值
									ops2 = {0, 1, SEM_UNDO};
		shmid = shmget(SHMKEY, 16 * K, 0777);//创建一个共享区
		addr = shmat(shmid, 0, 0);//共享存储区的附接到进程的虚拟空间上，返回地址
		arrp = (arr *)addr;//arrp 指向addr
		semid = semget(SEMKEY, 2, 0777);//创建一个信号量集描述
		for (i = 0; i < 256; i++)
		{
				semop(semid, &ops1, 1);//对信号量集中一个或几个信号量进行操作，释放资源
				printf("sem2: %d = %d\n", i, (*arrp)[in][0]);
				in = (in + 1) % 16;
				semop(semid, &ops2, 1);//对信号量集中一个或几个信号量进行操作，申请资源
		}
}