#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#define SHMKEY 70
#define SEMKEY 80
#define K 1024
typedef int arr[16][256];
int shmid;
int semid;
int main()
{
		int i, in = 0;
		char *addr;
		arr *arrp;
		struct sembuf ops1 = {0, -1, SEM_UNDO}, //ops1 表示结构组中成员个数，>0s申请资源，<0释放资源，0改变信号量的值
									ops2 = {1, 1, SEM_UNDO};
		extern cleanup();
		for (i = 0; i < 31; i++)
				signal(i, cleanup);
		shmid = shmget(SHMKEY, 16 * K, 0777 | IPC_CREAT);//创建一个共享区
		addr = shmat(shmid, 0, 0); //共享存储区的附接到进程的虚拟空间上，返回地址
		arrp = (arr *)addr;  //指向进程共享区地址
		semid = semget(SEMKEY, 2, 0777 | IPC_CREAT); //创建一个信号量集描述
		semctl(semid, 0, SETVAL, 16);//对信号量集的0号信号量控制操作
		semctl(semid, 1, SETVAL, 0);//对信号量集的1号信号量控制操作
		for (i = 0; i < 256; i++)
		{
				semop(semid, &ops1, 1);//对信号量集中一个或几个信号量进行操作。
				(*arrp)[in][0] = i;  //
				in = (in + 1) % 16;
				semop(semid, &ops2, 1);
		}
		sleep(1);//睡眠1s
}
cleanup()
{
		shmctl(shmid, IPC_RMID, 0);//撤消共享存储区，归还资源
		semctl(semid, 0, IPC_RMID, 0);//对信号量集的0号信号量控制清零操作
		exit(0);
}
/* sem2.c */


