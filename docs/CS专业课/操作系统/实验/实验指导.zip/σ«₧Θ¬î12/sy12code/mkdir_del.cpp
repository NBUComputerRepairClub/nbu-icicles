#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include "systemdata.h"
bool mkdir(char *dirname)
{
    int flag = 0, newp, newdinode;
    unsigned int i;
    struct dinode node;
    struct dir dir;
    // /目录下不能建目录
    if (!strcmp(cur_direct.name, "/"))
    {
        printf("你不能随便在/目录下建目录!!!\n");
        return false;
    }
    // 检查是否在自己的目录下，不是则不能建立目录
        struct dinode dd_i;
    dd_i = iget(cur_direct.d_ino);
    if (dd_i.di_uid != cur_psword.userid && strcmp(cur_psword.group, "root"))
    {
        printf("这不是你的家目录，你没有权限建立目录!!!\n");
        return false;
    } // 检查重名
    for (i = 0; i < cur_dir.size; i++)
    {
        if (!strcmp(dirname, cur_dir.direct[i].name) && cur_dir.direct[i].dir_flag == '1')
        {
            flag = 1;
            break;
        }
    }
    if (flag)
    {
        puts("存在重名目录，请换一个名字!!!");
        return false;
    }
    // 分配 i 结点建立目录
    newdinode = ialloc();
    if (!newdinode)
    {
        puts("i 结点分配失败!!!");
        return false;
    }
    newp = cur_dir.size;
    cur_dir.size++;
    strcpy(cur_dir.direct[newp].name, dirname);
    cur_dir.direct[newp].dir_flag = '1';
    cur_dir.direct[newp].d_ino = newdinode;
    node = iget(newdinode);
    node.di_gid = '1';
    node.di_mode = DEFAULTMODE;
    node.di_size = 0;
    node.di_uid = cur_psword.userid;
    iput(node, newdinode);
    dir.size = 2;
    strcpy(dir.direct[0].name, ".");
    dir.direct[0].dir_flag = '1';
    dir.direct[0].d_ino = newdinode;
    strcpy(dir.direct[1].name, "..");
    dir.direct[1].dir_flag = '1';
    dir.direct[1].d_ino = cur_direct.d_ino;
    sub_dir_put(dir, newdinode);            // 将子目录表写回
    sub_dir_put(cur_dir, cur_direct.d_ino); // 将当前目录表写回
    return true;
}
bool del(char *dirname)
{
    unsigned i;
        int flag = 0;
    if (!strcmp(cur_direct.name, "/"))
    {
        printf("用户目录不能随便删除!!!\n");
        return false;
    }
    // 检查是否在自己的目录下，不是则不能删除目录
    struct dinode dd_i;
    dd_i = iget(cur_direct.d_ino);
    if (dd_i.di_uid != cur_psword.userid && strcmp(cur_psword.group, "root"))
    {
        printf("这不是你的家目录，你没有权限删除文件或目录!!!\n");
        return false;
    } // 检查是否存在该文件或目录
    for (i = 0; i < cur_dir.size; i++)
    {
        if (!strcmp(dirname, cur_dir.direct[i].name))
        {
            flag = 1;
            break;
        }
    }
    if (!flag)
    {
        printf("没有你想要删除的文件!!!\n");
        return false;
    } // .和..目录不能删除
    if (!strcmp(dirname, ".") || !strcmp(dirname, ".."))
    {
        printf("不能删除此目录!!!\n");
        return false;
    }
    struct dinode node;
    unsigned id, j = 0;
    char yes_or_no;
    if (cur_dir.direct[i].dir_flag == '2') // 如果是文件则作相应处理
    {
        cout << "的确要删除此文件吗?(Y/N):";
        cin >> yes_or_no;
        if (yes_or_no == 'Y' || yes_or_no == 'y')
        {
            id = cur_dir.direct[i].d_ino;
            node = iget(id);
            while (node.di_addr[j] > 0 && j < 10)
            {
                bfree(node.di_addr[j]);
                j++;
            }
            ifree(id);
            cur_dir.size--;
            cur_dir.direct[i] = cur_dir.direct[cur_dir.size];
            sub_dir_put(cur_dir, cur_direct.d_ino);
            return true;
        }
    }
    else if (cur_dir.direct[i].dir_flag == '1') // 是目录
    {
        id = cur_dir.direct[i].d_ino;
        struct dir dir;
        dir = sub_dir_get(id);
        if (dir.size > 2) // 有子目录,因为已经存在.和..目录，所以要大于 2
        {
            puts("文件有子目录不能删除，请先删除子目录!!!");
            return false;
        }
        cout << "的确要删除此文件吗?(Y/N):";
        cin >> yes_or_no;
        if (yes_or_no == 'Y' || yes_or_no == 'y')
        {
            node = iget(id);
            bfree(node.di_addr[0]);
            cur_dir.size--;
            cur_dir.direct[i] = cur_dir.direct[cur_dir.size];
            sub_dir_put(cur_dir, cur_direct.d_ino); // 将新的文件目录写回
            return true;
        }
    }
    return false;
}