#include <stdio.h>
#include "systemdata.h"
    struct psw psw_get()
{
    int i, cout;
    struct psw newpsw;
    fseek(fp, PSWORDSTART, SEEK_SET);
    fread(&cout, sizeof(cout), 1, fp);
    newpsw.count = cout;
    for (i = 0; i < cout; i++)
    {
        fseek(fp, PSWORDSTART + (i + 1) * PSWORDSIZE, SEEK_SET);
        fread(&newpsw.psword[i], PSWORDSIZE, 1, fp);
    }
    return (newpsw);
}
void psw_put(struct psw addpsw)
{
    int i, cout;
    cout = addpsw.count;
    fseek(fp, PSWORDSTART, SEEK_SET);
    fwrite(&cout, sizeof(cout), 1, fp);
    for (i = 0; i < cout; i++)
    {
        fseek(fp, PSWORDSTART + (i + 1) * PSWORDSIZE, SEEK_SET);
        fwrite(&addpsw.psword[i], PSWORDSIZE, 1, fp);
    }
}
void psw_writeback()
{
    psw_put(thepsw);
}
void psw_read()
{
    thepsw = psw_get();
}