#include <stdio.h> 
#include "systemdata.h" 
#include "hash.h" 
struct superblock sup_get() 
{ 
 struct superblock supb; 
 fseek(fp,SUPSTART,SEEK_SET); 
 fread(&supb,SUPSIZE,1,fp); 
 return (supb); 
} 
void sup_put(struct superblock supb) 
{ 
 fseek(fp,SUPSTART,SEEK_SET); 
 fwrite(&supb,SUPSIZE,1,fp); 
} 
void install() 
{ 
 struct dir dir; 
 superblock=sup_get(); 
 thepsw=psw_get(); 
 dir=sub_dir_get(1); 
 cur_direct=dir.direct[2]; 
 cur_dir=sub_dir_get(cur_direct.d_ino); 
 users_dir=sub_dir_get(2); 
 inithash(); 
}