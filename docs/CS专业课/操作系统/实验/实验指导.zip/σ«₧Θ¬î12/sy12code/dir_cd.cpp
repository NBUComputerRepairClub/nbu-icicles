#include <stdio.h>
#include <iostream.h>
#include <string.h>
#include <stdlib.h>
#include "systemdata.h"
bool dir(void)
{
    unsigned int i, j, one, di_mode;
    struct dinode node;
    if (cur_direct.dir_flag != '1')
    {
        cout << "此文件不是目录文件!!!" << endl;
        return false;
    }
    for (i = 0; i < cur_dir.size; i++)
    {
        // 列出文件名或目录名
        if (cur_dir.direct[i].dir_flag == '1')
            cout << "[" << cur_dir.direct[i].name << "]\t\t";
        else
            cout << cur_dir.direct[i].name << "\t\t";
        node = iget(cur_dir.direct[i].d_ino); // 得到相应的 i 结点，以便得到详细信息
        // 显示存取权限
        di_mode = node.di_mode;
        char buf[9];
        for (j = 0; j < 9; j++)
        {
            one = di_mode % 2;
            di_mode = di_mode / 2;
            if (one)
                buf[j] = 'x';
            else
                buf[j] = '-';
        }
        for (int p = 8; p >= 0; p--)
            cout << buf[p];
        cout << "\t";
        // 如果是文件则列出大小
        if (cur_dir.direct[i].dir_flag == '1')
            cout << "<direct>\t\t";
        else
        {
            cout << node.di_size << "\t\t";
        }
        // 列出文件，目录的创建者名字
        for (unsigned int c = 0; c < thepsw.count; c++)
        {
            if (thepsw.psword[c].userid == node.di_uid)
                cout << thepsw.psword[c].username << "\t\t";
        }
        cout << endl;
    }
    return true;
}
bool cd(char *cmdname)
{
    struct dinode node;
    struct dir dir;
    int flag = 0;
    unsigned int i, j, id;
    for (i = 0; i < cur_dir.size; i++)
    {
        if (!strcmp(cmdname, cur_dir.direct[i].name))
        {
            flag = 1;
            break;
        }
    }
    if (flag)
    {
        if (cur_dir.direct[i].dir_flag == '2')
        {
            cout << "这不是目录!!!" << endl;
            return false;
        }
        // 如果 cur_dir 是主用户目录文件，则作特殊处理
        // 全局变量都保持不变
        if (cur_dir.direct[i].d_ino == 1)
            return true;
        // cur-dir 不是用户目录，则根据目录关系建立新的状态
        node = iget(cur_dir.direct[i].d_ino);
        id = cur_dir.direct[i].d_ino;
        cur_dir = sub_dir_get(id);
        dir = sub_dir_get(cur_dir.direct[1].d_ino);
        for (j = 0; j < dir.size; j++)
        {
            if (dir.direct[j].d_ino == id)
                break;
        }
        cur_direct = dir.direct[j];
        return true;
    }
    else
    {
        cout << "此文件不是目录文件或不存在此目录!!!" << endl;
        return false;
    }
}