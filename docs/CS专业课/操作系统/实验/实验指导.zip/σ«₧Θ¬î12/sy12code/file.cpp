#include "stdio.h"
#include "systemdata.h"
#include "string.h"
#include "hash.h"
bool creatfile(char filename[])
{
    int filenum = cur_dir.size;
    int i, ni;
    struct dinode d_i;
    struct dinode dd_i;
    dd_i = iget(cur_direct.d_ino);
    if (strcmp(cur_direct.name, "/") == 0)
    {
        printf("can not creat file here\n");
        return false;
    }
    for (i = 0; i < filenum; i++)
    {
        if (cur_dir.direct[i].dir_flag == '2' && strcmp(cur_dir.direct[i].name, filename) == 0)
        {
            printf("file already exist\n");
            return false;
        }
    }
    if (dd_i.di_uid != cur_psword.userid && strcmp(cur_psword.group, "root") != 0)
    {
        printf("你无权在其他用户中创建文件\n");
        return false;
    }
    ni = ialloc();
    cur_dir.direct[filenum].d_ino = ni;
    cur_dir.direct[filenum].dir_flag = '2';
    strcpy(cur_dir.direct[filenum].name, filename);
    cur_dir.size++; // add item in cur_dir
    d_i = iget(ni); //
    d_i.di_addr[0] = 0;
    d_i.di_creattime = 0;
        d_i.di_gid = (strcmp(cur_psword.group, "root") == 0) ? '0' : '1';
    d_i.di_mode = DEFAULTMODE;
    d_i.di_number = 0;
    d_i.di_size = 0;
    d_i.di_uid = cur_psword.userid;
    d_i.di_visittime = 0;                   // add and initiate dinode
    iput(d_i, ni);                          //
    sub_dir_put(cur_dir, cur_direct.d_ino); //当前目录回写
    return true;
}
bool access(unsigned int m, struct dinode di_node)
{
    int mode = di_node.di_mode;
    int j, one;
    int buf[9];
    for (j = 0; j < 9; j++)
    {
        one = mode % 2;
        mode = mode / 2;
        if (one)
            buf[j] = 1;
        else
            buf[j] = 0;
    }
    if (buf[3 + m])
        return true;
    else
        return false;
}
int fileopen(char filename[])
{
    int i, filenum;
    unsigned int n_di;
    struct dinode di_node;
    filenum = cur_dir.size;
    for (i = 0; i < filenum; i++)
    {
        if (cur_dir.direct[i].dir_flag == '2' && strcmp(cur_dir.direct[i].name, filename) == 0)
            break;
    }
    if (i == filenum)
    {
        printf("没有这个文件\n");
        return -1;
    }
    n_di = cur_dir.direct[i].d_ino; // find dinode number
    di_node = iget(n_di);
    if (strcmp(cur_psword.group, "root") != 0 && cur_psword.userid != di_node.di_uid) // not root or
        owner
        {
            if (access(0, di_node) == false)
            {
                printf("你没有权限打开\n");
                return -1; //没有权限；
            }
        }
    if (inodesearch(n_di) == NULL) // hash 表中不存在.
    {
        addinode(n_di);
        return n_di;
    }
    printf("文件已经打开\n");
    return -1;
}
bool fileclose(unsigned int dinode)
{
    int flag;
    flag = delinode(dinode);
    if (flag == -1)
        return false;
    return true;
}
int filewrite(unsigned int dinode, char *buf, int size)
{
    int i, j;
    struct inode *i_node;
    struct dinode di_node;
    di_node = iget(dinode);
    if (strcmp(cur_psword.group, "root") != 0 && cur_psword.userid != di_node.di_uid) // not root or
        owner
        {
            if (access(2, di_node) == false)
            {
                printf("没有权限写\n");
                return -1; //没有权限；
            }
        }
    i_node = inodesearch(dinode);
    if (i_node == NULL) // hash 表中不存在.
    {
        printf("文件没打开\n");
        return -1; //文件没打开.
    }
    else
    {
        for (i = 0; i < size / 512 && i < ADDRNUM; i++)
        {
            j = balloc();
            fseek(fp, (long)(fp + 512 * j), SEEK_SET);
            fwrite((buf + i * 512), 1, 512, fp);
            i_node->i_addr[i] = j;
            di_node.di_addr[i] = j;
        } //整块 j 为块号
        if (i == ADDRNUM)
            return 512 * ADDRNUM; //文件太大,剪断
        j = balloc();
        fseek(fp, (long)(512 * j), SEEK_SET);
        fwrite((buf + i * 512), 1, size % 512, fp);
        -97 -
            i_node->i_addr[i] = j;
        di_node.di_addr[i] = j;
        i++;
        i_node->i_addr[i] = 0;
        di_node.di_addr[i] = 0; //零头
    }                           //分配磁盘块,给 inode->addr,dinode.addr 赋值
    i_node->i_size = size;
    i_node->i_count = 1;
    i_node->i_flag = 0;
    i_node->i_number = 1;
    i_node->i_visittime = 0;
    di_node.di_number = 1;
    di_node.di_size = size;
    di_node.di_visittime = 0;
    iput(di_node, dinode);
    return size;
}
int fileread(unsigned int dinode, char *buf, int size)
{
    int i, j;
    struct inode *i_node;
    struct dinode di_node;
    di_node = iget(dinode);
    if (strcmp(cur_psword.group, "root") != 0 && cur_psword.userid != di_node.di_uid) // not root or
        owner
        {
            if (access(1, di_node) == false)
            {
                printf("没有权限读\n");
                return -1; //没有权限；
            }
        }
    i_node = inodesearch(dinode);
    if (i_node == NULL) // hash 表中不存在.
    {
        printf("文件没打开\n");
        return -1; //文件没打开.
    }
    else
    {
        if (i_node->i_size == 0)
        {
            printf("该文件为空\n");
            return -1;
        }
        for (i = 0; i < size / 512; i++)
        {
            j = i_node->i_addr[i];
            fseek(fp, (long)(512 * j), SEEK_SET);
            fread((buf + i * 512), 1, 512, fp);
        } //整块 j 为块号
        j = i_node->i_addr[i];
        fseek(fp, (long)(512 * j), SEEK_SET);
        -98 -
            fread((buf + i * 512), 1, size % 512, fp); //零头
    }
    di_node.di_visittime = 0;
    iput(di_node, dinode);
    i_node->i_visittime = 0;
    return size;
}