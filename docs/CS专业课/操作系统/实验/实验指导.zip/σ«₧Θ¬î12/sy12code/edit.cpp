#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "systemdata.h"
int size(char *ch)
{
    int i = 0;
    while (ch[i] != '\0')
    {
        i++;
    }
    return ++i;
}
char *input()
{
    int k = 0, j = 0, i = 1;
    char *buf = (char *)malloc(1024 * i);
    char ch[512];
    while (ch[j] != '$')
    {
        gets(ch);
        j = 0;
        while (ch[j] != '\0' && ch[j] != '$')
        {
            buf[k++] = ch[j++];
        }
        buf[k++] = '\n';
        buf[k] = '\0';
        if (size(buf) >= 1024 * i - 512)
        {
            i++;
            buf = (char *)realloc(buf, 512 * i);
        }
    };
    buf[k] = '\0';
    return buf;
}
int edit(char name[])
{
    char filename[DIRSIZE];
    char *readbuf, *writebuf;
    unsigned int n_di;
    int nn;
    int flag = 1;
    int closeflag = 1;
        char yn;
    struct dinode di_node;
    strcpy(filename, name);
    while (flag)
    {
        if ((n_di = fileopen(filename)) == -1)
        {
            printf("你想打开另一个文件吗？<Y>\n");
            scanf("%c", &yn);
            getchar();
            if (yn == 'y' || yn == 'Y')
            {
                printf("输入文件名\n");
                gets(filename);
                flag = 1;
            }
            else
                return 0;
        }
        else
            flag = 0;
    }
    closeflag = 0;
    di_node = iget(n_di);
    do
    {
        printf("1: 读文件\n");
        printf("2: 写文件（这将丢失文件原数据）\n");
        printf("3: 关闭文件\n");
        printf("4: 退出编辑\n");
        printf("你想做什么？\n");
        scanf("%d", &nn);
        getchar();
        switch (nn)
        {
        case 1:
            di_node = iget(n_di);
            readbuf = (char *)malloc(di_node.di_size);
            if (fileread(n_di, readbuf, di_node.di_size) != -1)
            {
                printf("%s", readbuf);
            }
            else
                printf("读入失败！\n");
            free(readbuf);
            break;
        case 2:
            if (strcmp(cur_psword.group, "root") != 0 && cur_psword.userid != di_node.di_uid) // not root
                or owner
                {
                    if (access(2, di_node) == false)
                    {
                        printf("没有权限写\n");
                        break; //没有权限；
                    }
                }
            printf("输入内容，以'$'结尾\n");
            writebuf = input();
            if (filewrite(n_di, writebuf, size(writebuf)) == -1)
                printf("写人失败！\n");
            free(writebuf);
            break;
        case 3:
            if (fileclose(n_di) == true)
                closeflag = 1;
            else
            {
                printf("无法关闭，可能不存在该文件，或该文件已经关闭！\n");
                closeflag = 1;
            }
            break;
        case 4:
            if (closeflag == 1)
                return 0;
            else
                printf("请先关闭文件,再退出！\n");
            break;
        default:
            printf("没有这个选项！\n");
            break;
        } // switch
    }     // do
    while (1);
} // edit