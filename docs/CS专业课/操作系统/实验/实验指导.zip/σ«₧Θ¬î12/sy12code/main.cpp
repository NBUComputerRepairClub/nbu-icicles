#include <stdio.h>
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include "systemdata.h"
using namespace std;
FILE *fp;                      // 磁盘文件指针
struct superblock superblock;  // 内存中超级块数据
struct hinode hinode[HASHNUM]; // HASH 表
struct psw thepsw;             // 用户表
struct direct cur_direct;      // 当前的目录项
struct dir cur_dir;            // 当前目录的子目录组
struct psword cur_psword;      // 当前用户名密码
struct dir users_dir;          // 用户文件表
int main()
{
    format();
    if (!(fp = fopen(FILENAME, "r+b")))
    {
        cout << "磁盘文件打开出错!!!";
        exit(0);
    }
    install();
    shell();
    fclose(fp);
    return 0;
}