#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "systemdata.h"
void format()
{
    char *buf;
    buf = (char *)malloc(DISKSIZE);
    if (!(fp = fopen(FILENAME, "w+b")))
        exit(0);
    //开辟 1M 大小的文件做磁盘
    fwrite(buf, DISKSIZE, 1, fp);
    fclose(fp);
    if (!(fp = fopen(FILENAME, "r+b")))
        exit(0);
    //将 1--3 号 i 结点初始化
    struct dinode addinode;
    addinode.di_addr[0] = 106;
    addinode.di_addr[1] = 0;
    addinode.di_gid = 'r';
    addinode.di_uid = 0;
    addinode.di_size = 0;
    addinode.di_mode = DEFAULTMODE;
    iput(addinode, 1);
    addinode.di_addr[0] = 107;
    addinode.di_addr[1] = 108;
    addinode.di_addr[2] = 109;
    addinode.di_addr[3] = 110;
    addinode.di_addr[4] = 0;
    addinode.di_gid = 'r';
    addinode.di_uid = 0;
    addinode.di_size = 0;
    addinode.di_mode = DEFAULTMODE;
    iput(addinode, 2);
    addinode.di_addr[0] = 131;
    addinode.di_addr[1] = 0;
    addinode.di_gid = 'r';
    addinode.di_uid = 1;
    addinode.di_size = 0;
    addinode.di_mode = DEFAULTMODE;
    iput(addinode, 3);
    //根目录初始化
    struct dir dir;
    dir.size = 3;
    dir.direct[0].d_ino = 1;
    dir.direct[0].dir_flag = '1';
    strcpy(dir.direct[0].name, ".");
    dir.direct[1].d_ino = 1;
    dir.direct[1].dir_flag = '1';
    strcpy(dir.direct[1].name, "..");
    dir.direct[2].d_ino = 2;
    dir.direct[2].dir_flag = '1';
    strcpy(dir.direct[2].name, "/");
    sub_dir_put(dir, 1);
    //主用户文件目录初始化
    dir.size = 3;
    dir.direct[0].d_ino = 2;
    dir.direct[0].dir_flag = '1';
    strcpy(dir.direct[0].name, ".");
    dir.direct[1].d_ino = 1;
    dir.direct[1].dir_flag = '1';
    strcpy(dir.direct[1].name, "..");
    dir.direct[2].d_ino = 3;
    dir.direct[2].dir_flag = '1';
    strcpy(dir.direct[2].name, "root");
    sub_dir_put(dir, 2);
    // root 用户目录初始化
    dir.size = 2;
    dir.direct[0].d_ino = 3;
    dir.direct[0].dir_flag = '1';
    strcpy(dir.direct[0].name, ".");
    dir.direct[1].d_ino = 2;
    dir.direct[1].dir_flag = '1';
    strcpy(dir.direct[1].name, "..");
    sub_dir_put(dir, 3);
    // root 用户名密码初始化
    struct psword addpsword;
    struct psw addpsw;
    addpsword.userid = 1;
    strcpy(addpsword.username, "root");
    strcpy(addpsword.password, "root");
    strcpy(addpsword.group, "root");
    addpsw.count = 1;
    addpsw.psword[0] = addpsword;
    psw_put(addpsw);
    //超级块初始化
        struct superblock initsupblock;
    initsupblock.s_isize = 500;
    initsupblock.s_fsize = DATANUM;
    int i, j, begin, end, data[bSTACKSIZE], instack, freenum;
    instack = (DATANUM - 1) % bSTACKSIZE; // 在堆栈中的块数
    freenum = (DATANUM - 1) / bSTACKSIZE; // 存在数据区的组数
    begin = end = DATASTART + 1;
    for (i = 0; i < instack; i++)
    {
        initsupblock.s_free[i] = end;
        end++;
    }
    for (j = 0; j < freenum; j++)
    {
        // cout<<begin<<endl;
        for (i = 0; i < bSTACKSIZE; i++)
        {
            data[i] = end;
            // cout<<end<<" ";
            end++;
        }
        fseek(fp, begin * BLOCKSIZE, SEEK_SET);
        fwrite(data, sizeof(data), 1, fp);
        begin = data[0];
    }
    initsupblock.s_nfree = DATANUM - 1;
    initsupblock.s_pfree = instack - 1;
    initsupblock.s_ninode = INODENUM - 4;
    for (i = 0; i < INODENUM - 4; i++)
        initsupblock.s_inode[i] = i + 4;
    initsupblock.s_pinode = INODENUM - 5;
    initsupblock.s_rinode = 0;
    initsupblock.s_fmod = 0;
    fseek(fp, SUPSTART, SEEK_SET);
    fwrite(&initsupblock, SUPSIZE, 1, fp);
    fclose(fp);
}