#include <stdio.h>
#include <string.h>
#include <iostream.h>
#include <conio.h>
#include "systemdata.h"
#define EXIT 10
#define LOGOUT 9
#define CMDNUM 13
int get_cmd_id(char *cmd)
{
    char *optable[] = {"dir", "ls", "cd", "mkdir", "del", "adduser",\ 
 "deluser",
                       "creat", "edit", "chmod", "pw", "logout", "exit"};
    int i, flag = 0;
    for (i = 0; i < CMDNUM; i++)
    {
        if (!strcmp(cmd, optable[i]))
        {
            flag = 1;
            break;
        }
    }
    if (flag)
        return i;
    else
    {
        cout << "没有这个命令!!!" << endl;
        return -1;
    }
}
int docmd(char *cmd)
{
    int opp = 0, parp = 0, cmd_id;
    char op[20], par[20];
    while (*cmd == ' ')
        cmd++;
    while (*cmd != ' ' && *cmd != '\0')
    {
        op[opp] = *cmd;
        cmd++;
        opp++;
    }
    op[opp] = '\0';
    while (*cmd == ' ')
        cmd++;
    while (*cmd != '\0')
    {
        par[parp] = *cmd;
            // cout<<*cmd;
            cmd++;
        parp++;
    }
    par[parp] = '\0';
    // cout<<par;
    cmd_id = get_cmd_id(op);
    switch (cmd_id)
    {
    case 0:
    case 1:
        dir();
        break;
    case 2:
        cd(par);
        break;
    case 3:
        mkdir(par);
        break;
    case 4:
        del(par);
        break;
    case 5:
        adduser(par, "user");
        break;
    case 6:
        deluser(par);
        break;
    case 7:
        creatfile(par);
        break;
    case 8:
        edit(par);
        break;
    case 9:
        chmod(par);
        break;
    case 10:
        pw();
        break;
    case 11:
        printf("用户已注销!!!\n");
        return LOGOUT;
    case 12:
        cout << "已退出文件系统!!!\n";
        return EXIT;
    default:
        return 0;
    }
    return 1;
}
void printinfor()
{
    printf("\t|---------------------------------------------------------|\n");
    printf("\t| |\n");
    printf("\t| 文件系统(VFS)实例 |\n");
    printf("\t| |\n");
    printf("\t| 2002 - 7 - 9 |\n");
    printf("\t|---------------------------------------------------------|\n\n");
}
bool shell()
{
    char cmd[20];
    int result;
start:
    printinfor();
    while (!login())
        ;
    do
    {
        printf("[%s @ localhost %s] ", cur_psword.username, cur_direct.name);
        gets(cmd);
        result = docmd(cmd);
    } while (result != LOGOUT && result != EXIT);
    if (result == LOGOUT)
        goto start;
    return true;
}
