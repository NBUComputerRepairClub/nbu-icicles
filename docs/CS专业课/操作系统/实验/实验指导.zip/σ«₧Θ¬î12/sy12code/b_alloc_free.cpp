#include <stdio.h>
#include <iostream.h>
#include <stdlib.h>
#include "systemdata.h"
    int
    balloc()
{
    struct superblock block;
    int addr, bindex[bSTACKSIZE];
    fseek(fp, SUPSTART, SEEK_SET);
    fread(&block, SUPSIZE, 1, fp); // 读出超级块内容
    if (block.s_nfree <= 0)
    {
        cout << "已没有空闲盘块可分配！！！";
        return 0;
    }
    if (block.s_pfree == 0 && block.s_nfree > bSTACKSIZE) // 判断堆栈中空闲块是否分配完
    {
        addr = block.s_free[0]; // 将堆栈底块号读出，为被分配块号
            fseek(fp, addr * BLOCKSIZE, SEEK_SET);
        fread(bindex, sizeof(bindex), 1, fp);
        for (int i = 0; i < bSTACKSIZE; i++)
            block.s_free[i] = bindex[i]; // 将 addr 块中的数据读出，并存入堆栈
        block.s_pfree = bSTACKSIZE - 1; // 堆栈指针指向满的位置
    }
    else
    { // 堆栈中可以直接分配
        addr = block.s_free[block.s_pfree];
        block.s_nfree--;
        block.s_pfree--;
    }
    fseek(fp, SUPSTART, SEEK_SET);
    fwrite(&block, SUPSIZE, 1, fp); // 将超级块写回磁盘文件
    return addr;
}
void bfree(int id)
{
    struct superblock block;
    int bindex[bSTACKSIZE];
    fseek(fp, SUPSTART, SEEK_SET);
    fread(&block, SUPSIZE, 1, fp);
    if (block.s_pfree >= bSTACKSIZE - 1) // 堆栈已经放满
    {
        for (int i = 0; i < bSTACKSIZE - 1; i++)
        {
            bindex[i] = block.s_free[i];
        }
        fseek(fp, DATASTART + id * BLOCKSIZE, SEEK_SET);
        fwrite(&bindex, sizeof(bindex), 1, fp);
        block.s_nfree++;
        block.s_pfree = 0; // 堆栈指针指向堆栈底
        block.s_free[0] = id;
    }
    else
    { // 直接释放
        block.s_nfree++;
        block.s_pfree++;
        block.s_free[block.s_pfree] = id;
    }
    fseek(fp, SUPSTART, SEEK_SET);
    fwrite(&block, SUPSIZE, 1, fp); // 将超级块写回磁盘文件
}