#include <stdio.h>
#include <string.h>
#include "conio.h"
#include "systemdata.h"
bool login()
{
    unsigned int no, i, k;
    int flag = 0;
    char username[USERSIZE], password[PWSIZE];
    printf("用户名: ");
    gets(username);
    for (i = 0; i < thepsw.count; i++)
        if (!strcmp(thepsw.psword[i].username, username))
        {
            flag = 1;
            no = i;
            break;
        }
    if (!flag)
    {
        printf("该用户不存在!\n");
        return false;
    }
    else
    {
        printf("密码: ");
        // gets(password);
        for (int z = 0; (password[z] = getch()) != '\r'; z++)
            putch('*');
            password[z] = '\0';
        putch('\n');
        if (strcmp(thepsw.psword[no].password, password))
        {
            printf("用户名和密码不匹配!\n");
            return false;
        }
        else
        {
            strcpy(cur_psword.group, thepsw.psword[no].group);
            strcpy(cur_psword.username, thepsw.psword[no].username);
            strcpy(cur_psword.password, thepsw.psword[no].password);
            cur_psword.userid = thepsw.psword[no].userid;
            for (k = 0; k < cur_dir.size; k++)
            {
                if (!strcmp(cur_dir.direct[k].name, username))
                {
                    cur_direct = cur_dir.direct[k];
                    cur_dir = sub_dir_get(cur_dir.direct[k].d_ino);
                    break;
                }
            }
            puts("<恭喜，你已经成功登录>");
            return true;
        }
    }
}