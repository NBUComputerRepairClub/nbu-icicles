#include "stdio.h"
#include "systemdata.h"
#include "malloc.h"
void inithash()
{
int i;
struct inode i_node;
struct inode *pi_node;
i_node.i_ino =0;
i_node.i_forw =NULL;
i_node.i_back =NULL;
for(i=0;i<HASHNUM;i++)
{
pi_node=(struct inode*)malloc(sizeof(struct inode));
*pi_node=i_node;
hinode[i].i_forw=pi_node;
} // 10 linklist head
}
void addinode(int n)
{
int i=n%10;
int k=0,nbuf;
struct inode *i_node=(inode *)malloc(sizeof(struct inode));
struct inode *pi_node=hinode[i].i_forw;
struct dinode di_node;
di_node=iget(n);
while((nbuf=di_node.di_addr [k])!=0)
{
i_node->i_addr [k]=nbuf;
k++;
}
i_node->i_ino =n;
i_node->i_addr [k]=0;
i_node->i_back =NULL;
i_node->i_count=1;
i_node->i_creattime =di_node.di_creattime ;
i_node->i_flag =0;
i_node->i_forw =NULL;
i_node->i_gid =di_node.di_gid;
i_node->i_mode =di_node.di_mode ;
i_node->i_number =di_node.di_number;
i_node->i_size =di_node.di_size ;
i_node->i_uid =di_node.di_uid ;
i_node->i_visittime =di_node.di_visittime ; // init inode
pi_node=hinode[i].i_forw ;
while(pi_node->i_forw !=NULL)
{
pi_node=pi_node->i_forw;
} //search end
pi_node->i_forw =i_node;
i_node->i_back =pi_node; //insert a inode to hash list
}
int delinode(unsigned int n)
{
int i;
i=n%10;
struct inode* pinode;
struct inode* ppinode;
pinode=hinode[i].i_forw ;
ppinode=pinode;
while(pinode!=NULL&&pinode->i_ino!=n)
{
ppinode=pinode;
pinode=pinode->i_forw;
}
if(pinode==NULL)
{
printf("该文件已经关闭！\n");
return -1;
}
ppinode->i_forw =pinode->i_forw ;
free(pinode);
return n;
}
struct inode* inodesearch(unsigned int n)
{
    int i;
i=n%10;
struct inode* pinode;
pinode=hinode[i].i_forw ;
while(pinode!=NULL&&pinode->i_ino!=n)
{
pinode=pinode->i_forw;
}
if(pinode==NULL)
{
return NULL;
}
else return pinode;
}