#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include "systemdata.h"
using namespace std;
int ialloc()
{
int ninode;
struct superblock getblock;
fseek(fp,SUPSTART,SEEK_SET);
fread(&getblock,SUPSIZE,1,fp);
if(getblock.s_ninode<=0)
{
cout<<"没有空闲i结点，请修改程序！！！";
return 0;
}
getblock.s_ninode--;
ninode=getblock.s_inode[getblock.s_pinode--];
fseek(fp,SUPSTART,SEEK_SET);
fwrite(&getblock,SUPSIZE,1,fp);
struct dinode node;
for(int i=0;i<ADDRNUM;i++)
node.di_addr[i]=0;
iput(node,ninode); //将新分配的i节点addr[]初始化为0
return (ninode);
}
void ifree(int i)
{
struct superblock getblock;
fseek(fp,SUPSTART,SEEK_SET);
fread(&getblock,SUPSIZE,1,fp);
if(getblock.s_ninode>=500)
{
cout<<"系统错误：i结点回收出错，请修改程序！！！";
exit(0);
}
getblock.s_ninode++;
getblock.s_inode[++getblock.s_pinode]=i;
fseek(fp,SUPSTART,SEEK_SET);
fwrite(&getblock,SUPSIZE,1,fp);
}