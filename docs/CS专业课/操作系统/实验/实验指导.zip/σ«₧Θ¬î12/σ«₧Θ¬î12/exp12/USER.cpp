#include <stdio.h>
#include <string.h>

#include <conio.h>
#include <stdlib.h>
#include "systemdata.h"
#include <iostream>
using namespace std;
unsigned int generateid()
{
unsigned int i,id,temp=0;
for(i=0;i<thepsw.count;i++)
if(temp<thepsw.psword[i].userid) temp=thepsw.psword[i].userid;
id=temp+1;
return id;
}
bool adduser(char name[],char group[])
{
unsigned int i;
int j;
if(strcmp(cur_psword.username,"root")) //当前目录项假如是根，则添加用户
{
printf("您不能添加新用户，只有root才有添加用户的权限!\n");
return false;
}
if(!strcmp(name,"root"))
{
printf("不能添加root用户!\n");
return false;
}
for(i=0;i<thepsw.count;i++)
if(!strcmp(thepsw.psword[i].username,name))
{
printf("该用户已存在!\n");
return false;
}
char pwd[20],passwordok[20];
printf("密码: ");
int z=0;
for(int z=0;(pwd[z]=getch())!='\r';z++) putch('*');
pwd[z]='\0';
putch('\n');
printf("重新输入一次:");
for(z=0;(passwordok[z]=getch())!='\r';z++) putch('*');
passwordok[z]='\0';
putch('\n');
if(strcmp(pwd,passwordok))
{
printf("两次输入密码不一样，添加用户失败!!!\n");
return false;
}
unsigned int userid;
userid=generateid();//产生用户id
j=thepsw.count;
thepsw.count+=1;
thepsw.psword[j].userid=userid;
strcpy(thepsw.psword[j].username,name);
//puts(thepsw.psword[j].username);
strcpy(thepsw.psword[j].password,pwd);
strcpy(thepsw.psword[j].group,group);//在thepsw中添加新的用户内容
int ni,nb;
ni=ialloc();
nb=balloc();//分配一个i节点和一个磁盘块
struct dinode di_new;
di_new=iget(ni);
di_new.di_uid=userid;
di_new.di_gid='0';
di_new.di_mode=DEFAULTMODE;
di_new.di_addr[0]=nb;
di_new.di_addr[1]=0;
di_new.di_size=0;
di_new.di_number=0;
di_new.di_creattime=0;
di_new.di_visittime=0;//初始化磁盘i节点
j=users_dir.size;
strcpy(users_dir.direct[j].name,name);
users_dir.direct[j].dir_flag='1';
users_dir.direct[j].d_ino=ni;
users_dir.size++;
if(!strcmp(cur_direct.name,"/"))
cur_dir=users_dir;
struct dir buf_dir;
buf_dir.size=2;
strcpy(buf_dir.direct[0].name,".");
buf_dir.direct[0].d_ino=ni;
buf_dir.direct[0].dir_flag='1';
strcpy(buf_dir.direct[1].name,"..");
buf_dir.direct[1].d_ino=2;
buf_dir.direct[1].dir_flag='1';
psw_writeback();
sub_dir_put(users_dir,2);
iput(di_new,ni);
sub_dir_put(buf_dir,ni); // 将目录表放回指定的i结点子目录
printf("成功添加了新用户!\n");
return true;
}
void deluser(char name[])
{
if(strcmp(cur_psword.username,"root")) printf("您没有删除用户的权限，只有root才能删除用户!\n");
else
{ if(!strcmp(name,"root")) printf("不能删除root用户!\n");
else
{
char yes_or_no;
cout<<"的确要删除此用户吗?(Y/N):";
cin>>yes_or_no;
if(yes_or_no=='Y' || yes_or_no=='y')
{
unsigned int i;
int flag=0;
for(i=0;i<thepsw.count;i++)
if(!strcmp(thepsw.psword[i].username,name))
{
flag=1;
break;
}
if(!flag)
printf("该用户不存在!\n");
else
{ unsigned int j,ni;
struct dir new_dir;
for(j=0;j<cur_dir.size;j++)
if(!strcmp(users_dir.direct[j].name,name))
{
ni=users_dir.direct[j].d_ino;
new_dir=sub_dir_get(ni);
break;
}
if(new_dir.size>2)
printf("用户目录非空，无法删除!\n");
else
{
struct dinode node;
node=iget(ni);
int k=0;
while(node.di_addr[k]>0 && k<10)
{
bfree(node.di_addr[k]);
k++;
}
ifree(ni);
users_dir.size--;
users_dir.direct[j]=users_dir.direct[users_dir.size];
sub_dir_put(users_dir,2);
if(!strcmp(cur_direct.name,"/"))
cur_dir=users_dir;
thepsw.count--;
thepsw.psword[i]=thepsw.psword[thepsw.count];
psw_put(thepsw);
printf("成功删除了一个用户\n");
}
}}}}}