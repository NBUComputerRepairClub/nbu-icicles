#ifndef __SYSTEMDATA
#define __SYSTEMDATA

// 磁盘文件的参数
#define DISKSIZE 1024*1024 // 磁盘文件大小
#define BLOCKSIZE 512 // 磁盘块大小
#define FILENAME "disk.txt"
// 超级块参数
#define SUPBLOCK 5 // 超级块所需盘块
#define bSTACKSIZE 50 // 空闲盘块栈大小
#define iSTACKSIZE 500 // 空闲i接点栈大小
#define SUPSTART BLOCKSIZE // 超级块起始的物理地址
#define SUPSIZE sizeof(struct superblock) // 超级块大小
// i结点参数
#define INODESIZE sizeof(struct dinode) // 一个i结点大小
#define INODENUM_B 5 // 每个盘块i结点个数
#define INODEBLOCK 100 // i结点所需盘块
#define INODENUM 500 // i结点数目
#define ADDRNUM 13 // i结点可连接的盘块数
#define INODESTART 6*BLOCKSIZE // i界点起始的物理地址
// 用户密码区参数
#define USERSIZE 20 // 用户名长度
#define PWSIZE 30 // 密码长度
#define GROUPSIZE 20 // 组名长度
#define USERNUM 68 // 最多用户个数(其实比最大数多几个)
#define USERBLOCK 14 // 用户密码去所需盘块
#define PSWORDSTART 111*BLOCKSIZE // 用户密码区起始地址
#define PSWORDSIZE sizeof(struct psword) // 密码记录项长度
// 主用户目录区参数（特殊的文件目录，初始化就确定）
#define ROOTSTART 106*BLOCKSIZE // /目录块地址
#define DIRBLOCK 4 // 主用户目录所需磁盘块数
#define DIRSTART 107*BLOCKSIZE // 主用户目录起始地址
// 文件目录一般参数
#define DIRECTSIZE sizeof(struct direct) // 目录项长度
#define DIRECTNUM 16 // 每块最多可分配目录项的数目
#define DIRECTSIZE_A 30 // 实际分配目录项长度
#define DIRSIZE 20 // 目录文件名长度
#define DIRNUM (10*DIRECTNUM) // 最大子目录数(i结点可连接10个盘块，每块可放17项)
#define DATASTART 131 // 数据区开始地址
#define DATANUM 1917 // 数据区块数
#define HASHNUM 10 // HASH表长度
#define DEFAULTMODE 00770 //默认权限
struct dinode{
unsigned int di_uid; // 拥有该文件的用户
unsigned char di_gid; // 拥有该文件的组0：ROOT 1：USER
unsigned int di_mode; // 存取权限
unsigned int di_addr[ADDRNUM]; // 文件物理地址
unsigned long di_size; // 文件大小
unsigned short di_number; // 文件连接数
unsigned int di_creattime; // 文件创建时间
unsigned int di_visittime; // 最近访问时间
};
struct inode{
unsigned int i_ino; // 磁盘i结点标号
unsigned short i_uid; // 拥有该文件的用户
unsigned char i_gid; // 拥有该文件的组
unsigned int i_mode; // 存取权限
unsigned int i_addr[ADDRNUM]; // 文件物理地址
unsigned long i_size; // 文件大小
unsigned short i_number; // 文件连接数
unsigned int i_creattime; // 文件创建时间
unsigned int i_visittime; // 最近访问时间
unsigned char i_flag; // 上锁标记
unsigned int i_count; // 引用计数
struct inode *i_forw; // 前向指针
struct inode *i_back; // 后向指针
};
struct superblock{
unsigned short s_isize; // i结点数目
unsigned long s_fsize; // 数据块数目
unsigned int s_nfree; // 空闲盘块数
unsigned short s_pfree; // 空闲块指针
unsigned int s_free[bSTACKSIZE]; // 空闲块堆栈
unsigned int s_ninode; // 空闲i结点数
unsigned short s_pinode; // 空闲i结点指针
unsigned int s_inode[iSTACKSIZE]; // 空闲i结点堆栈
unsigned int s_rinode; // 铭记i结点
unsigned char s_fmod; // 修改标记(0：未修改，1修改)
};
struct direct{
char name[DIRSIZE]; // 目录名
unsigned int d_ino; // 目录对应的i结点号
unsigned char dir_flag; // 1：目录；2：文件
};
struct dir{
struct direct direct[DIRNUM]; // 目录结构项
unsigned int size; // 项的数目
};
struct psword{
unsigned int userid; // 用户id
char username[USERSIZE]; // 用户名
char password[PWSIZE]; // 用户密码
char group[GROUPSIZE]; // 用户所属组
};
struct psw{
    struct psword psword[USERNUM]; // 用户记录表
unsigned int count; // 用户记录个数
};
struct hinode{
struct inode *i_forw; // hash表头指针
};
// 全局变量定义如下：
extern struct superblock superblock; // 内存中超级块数据
extern FILE *fp; // 磁盘文件指针
extern struct hinode hinode[HASHNUM]; // HASH表
extern struct psw thepsw; // 用户表
extern struct direct cur_direct; // 当前的目录项
extern struct dir cur_dir; // 当前目录的子目录组
extern struct psword cur_psword; // 当前用户名密码
extern struct dir users_dir; // 用户文件表
// 函数定义
// 底层函数，主要操作磁盘文件
extern void format(); // 格式化文件系统
extern void install(); // 装载文件系统
extern struct dinode iget(int); // 根据i结点得到磁盘i结点
extern void iput(struct dinode,int); // 将磁盘i结点放入指定的i结点块中
extern int ialloc(); // 分配一个i结点，返回i结点号
extern void ifree(int); // 将指定的i结点释放
extern int balloc(); // 分配一块磁盘块，返回盘块号
extern void bfree(int); // 将指定的磁盘块释放
extern struct psw psw_get(); // 读psw信息
extern void psw_put(struct psw); // 写psw信息
extern void psw_read(); // 将psw中的用户信息读入内存 thepsw 中
extern void psw_writeback(); // 将 thepsw 写回磁盘
extern struct dir sub_dir_get(int); // 根据i结点号，返回目录表
extern void sub_dir_put(struct dir,int);
//extern void sub_dir_read(int); // 根据i结点号，将目录表读入cur_dir
//extern void sub_dir_writeback(struct dir,int);
// 将目录表放回指定的i结点子目录区
extern void users_dir_writeback(); // 是上面函数的一个特例，放回的目录表是
// 用户目录表
//-------------------------------------------------------------
// 命令功能函数
extern bool login(void); // 登录到文件系统
extern void logout(void); // 注销用户
extern bool dir(void); // 列出目录
extern bool cd(char *); // 改变目录
extern bool mkdir(char *); // 创建目录
extern bool del(char *); // 删除目录或文件
extern bool adduser(char *,char *); // 增加用户
extern void deluser(char *); // 删除用户
extern bool shell(void); // 命令解析
extern bool chmod(char *); // 改变文件权限
extern bool pw(void); // 修改用户密码
extern bool creatfile(char *); // 创建文件
extern int edit(char *); // 编辑文件
//--------------------------------
// 文件操作函数
// 函数finished by murphydai
//extern bool delfile(char *);
extern int fileopen(char *); // 打开文件
extern bool fileclose(unsigned int); // 关闭文件
extern int fileread(unsigned int,char *,int); // 读文件
extern int filewrite(unsigned int ,char*,int); // 写文件
extern bool access(unsigned int ,struct dinode ); // 文件访问控制
extern void inithash();
extern void addinode(int);
int delinode(unsigned int );
struct inode* inodesearch(unsigned int );
#endif