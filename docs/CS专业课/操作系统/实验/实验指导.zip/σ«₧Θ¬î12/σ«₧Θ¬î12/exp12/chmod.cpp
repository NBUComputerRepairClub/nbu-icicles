#include <stdio.h>
#include <iostream>
#include <string.h>
#include "systemdata.h"
using namespace std;
bool chmod(char * filename)
{
unsigned int i,flag=0;
// 检查是否在自己的目录下，不是则不能改变文件权限
struct dinode dd_i;
dd_i=iget(cur_direct.d_ino);
if(dd_i.di_uid!=cur_psword.userid && strcmp(cur_psword.group,"root"))
{
    printf("这不是你的家目录，你不能改变文件权限!!!\n");
return false;
}
// 查看该目录下是否有该文件
for(i=0;i<cur_dir.size;i++)
{
if(!strcmp(filename,cur_dir.direct[i].name))
{
flag=1;
break;
}
}
if(!flag)
{
cout<<"该目录下找不到该文件!!!"<<endl;
return false;
}
if(cur_dir.direct[i].dir_flag=='1')
{
cout<<"目录不能改变权限!!!"<<endl;
return false;
}
int newmod;
printf("请输入新权限:");
scanf("%o",&newmod);
getchar();
struct dinode sub_i;
sub_i=iget(cur_dir.direct[i].d_ino);
sub_i.di_mode=newmod;
iput(sub_i,cur_dir.direct[i].d_ino);
return true;
}