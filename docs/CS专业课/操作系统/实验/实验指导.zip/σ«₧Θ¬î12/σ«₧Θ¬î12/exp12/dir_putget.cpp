#include <stdio.h>
#include <iostream>
#include "systemdata.h"
using namespace std;
struct dir sub_dir_get(int id)
{
int i,j,count;
struct dinode node;
struct dir dir;
dir.size=0;
node=iget(id);
for(i=0;i<10 && node.di_addr[i]>0;i++)
{
// 读出这一块存放的目录项数
fseek(fp,node.di_addr[i]*BLOCKSIZE,SEEK_SET);
fread(&count,sizeof(count),1,fp);
// 读出目录项
for(j=1;j<=count;j++)
{
fseek(fp,node.di_addr[i]*BLOCKSIZE+j*DIRECTSIZE_A,SEEK_SET);
fread(&dir.direct[dir.size],DIRECTSIZE,1,fp);
dir.size++; // 读出一项则计数加一
}
}
return (dir);
}
void sub_dir_put(struct dir dir,int id)
{
int i,j,p=0,arraynum,left,directnum;
struct dinode node;
node=iget(id);
directnum=DIRECTNUM; // 每块磁盘块能存放的目录项数目
arraynum=dir.size / DIRECTNUM; // dir中目录项需要几块整块的磁盘块
left=dir.size % DIRECTNUM; // 零头项的数目
// 完整块的存放（这些块都是放满的）
for(i=0;i<arraynum;i++)
{
if(node.di_addr[i]==0) node.di_addr[i]=balloc(); // 没有盘块则分配一块
// 将这一块的目录项数写入
fseek(fp,node.di_addr[i]*BLOCKSIZE,SEEK_SET);
fwrite(&directnum,sizeof(directnum),1,fp);
// 写入目录项
for(j=1;j<=directnum;j++,p++)
{
fseek(fp,node.di_addr[i]*BLOCKSIZE+j*DIRECTSIZE_A,SEEK_SET);
fwrite(&dir.direct[p],DIRECTSIZE,1,fp);
}
}
// 以下保存零头项
if(node.di_addr[i]==0) node.di_addr[i]=balloc(); // 没有盘块则分配
// 写入零头项数目
fseek(fp,node.di_addr[i]*BLOCKSIZE,SEEK_SET);
fwrite(&left,sizeof(left),1,fp);
// 保存零头项
for(j=1;j<=left;j++,p++)
{
fseek(fp,node.di_addr[i]*BLOCKSIZE+j*DIRECTSIZE_A,SEEK_SET);
fwrite(&dir.direct[p],DIRECTSIZE,1,fp);
}
// 以下将没有用到的磁盘块释放
i++;
while(i<10)
{
if(node.di_addr[i])
{
bfree(node.di_addr[i]);
node.di_addr[i]=0;
}
i++;
}
iput(node,id);
}
void sub_dir_writeback(struct dir dir,int id)
{
sub_dir_put(dir,id);
}