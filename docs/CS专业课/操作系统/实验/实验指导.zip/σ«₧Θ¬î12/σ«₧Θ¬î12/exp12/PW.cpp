#include <stdio.h>
#include <conio.h>
#include <string.h>
#include "systemdata.h"
bool pw()
{
unsigned int i,flag=0;int z=0;
char password[PWSIZE],passwordok[PWSIZE];
printf("新密码: ");
for(int z=0;(password[z]=getch())!='\r';z++) putch('*');
password[z]='\0';
putch('\n');
printf("重新输入一次:");

for(z=0;(passwordok[z]=getch())!='\r';z++) putch('*');
passwordok[z]='\0';
putch('\n');
if(strcmp(password,passwordok))
{
printf("两次输入密码不一样，修改失败!!!\n");
return false;
}
for(i=0;i<thepsw.count;i++)
if(!strcmp(thepsw.psword[i].username,cur_psword.username))
{
flag=1;
break;
}
if(!flag)
{ printf("用户没有登录!!!\n"); return false; }
strcpy(thepsw.psword[i].password,password);
psw_writeback();
printf("密码修改成功!!!\n");
return true;
}