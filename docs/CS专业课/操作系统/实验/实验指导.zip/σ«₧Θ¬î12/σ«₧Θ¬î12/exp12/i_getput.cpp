#include <stdio.h>
#include "systemdata.h"
struct dinode iget(int id)
{
struct dinode newdinode;
fseek(fp,long(INODESTART+id*INODESIZE),SEEK_SET);
fread(&newdinode,INODESIZE,1,fp);
return (newdinode);
}
void iput(struct dinode node,int id)
{
fseek(fp,long(INODESTART+id*INODESIZE),SEEK_SET);
fwrite(&node,INODESIZE,1,fp);
}
