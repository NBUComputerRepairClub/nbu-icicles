#define N 20
#include <stdio.h>
//#include <conio.h>
typedef struct pcb /* 进程控制块定义 */
{
	char pname[N];  //进程名称
	int runtime;    //运行时间
	int arrivetime; //到达时间
	char state;     //状态，R未完成，C完成运行
	struct pcb *next; //指向下一个进程
} PCB;
PCB head_input; //就绪队列头指针
PCB head_run;   //运行队列头指针
static char R = 'r', C = 'c'; //状态
unsigned long current; //记录系统当前时间
void inputprocess();   /* 建立进程函数 */
int readyprocess();    /* 建立就绪队列函数 */
int readydata();       /* 判断进程是否就绪函数 */
int runprocess();      /* 运行进程函数 */
int readyprocess()
{
	while (1)
	{
		if (readydata() == 0) //判断就绪队列是否还有需要运行的进程
			return 1;
		else
			runprocess();
	}
}
int readydata() //判断就绪队列是否为空
{
	PCB *p1, *p2, *p3;
	if (head_input.next == NULL)//就绪队列无进程
	{
		if (head_run.next == NULL) //不存在正在运行的进程
			return 0;
		else
			return 1;
	}
	p1 = head_run.next; //指向下一个进程
	p2 = &head_run;     //指向当前进程
	while (p1 != NULL)  // p2指向最后一个进程
	{
		p2 = p1;
		p1 = p2->next;
	}
	p1 = p2;              // p1指向最后一个进程
	p3 = head_input.next; //
	p2 = &head_input;     // p1指向head进程
	while (p3 != NULL) //进程正在运行的完成，输出
	{
		if (((unsigned long)p3->arrivetime <= current) && (p3->state == R))
		{
			printf("Time slice is %8ld( time %4ld); Process %s start.\n",
				   current, (current + 500) / 1000, p3->pname);
			p2->next = p3->next;
			p3->next = p1->next;
			p1->next = p3;
			p1 = p3;
			p3 = p2;
		}
		p2 = p3;
		p3 = p3->next;
	}
	return 1;
}

int runprocess()  //运行进程
{
	PCB *p1, *p2;
	if (head_run.next == NULL)
	{
		current++;
		return 1;
	}
	else
	{
		p1 = head_run.next;//从第一个进程开始
		p2 = &head_run; //指向头指针
		while (p1 != NULL)//还存在运行进程
		{
			p1->runtime--; //运行时间-1
			current++; //当前时间+1
			if (p1->runtime <= 0) //输出，完成进程
			{
				printf("Time slice is %8ld( time %4ld); Process %s end.\n",
					   current, (current + 500) / 1000, p1->pname);
				p1->state = C; //完成
				p2->next = p1->next; //退出就绪队列
				free(p1); //释放该进程
				p1 = p2->next; //继续判断下一个
			}
			else
			{
				p2 = p1; //执行下一个进程
				p1 = p2->next;
			}
		}
		return 1;
	}
}
void inputprocess() //输入进程数据
{
	PCB *p1, *p2;
	int i, num;
	unsigned long max = 0;
	printf("How many processes do you want to run:");
	scanf("%d", &num);//输入进程个数
	p2 = &head_input;
	for (i = 0; i < num; i++)
	{
		p1 = (PCB *)malloc(sizeof(PCB));
		p2->next = p1;
		printf("No.%3d process input pname:", i + 1);
		scanf("%s", p1->pname);//输入进程名字
		printf(" runtime:");
		scanf("%d", &(p1->runtime));//输入运行名字
		printf(" arrivetime:");
		scanf("%d", &(p1->arrivetime));//输入到达时间
		p1->runtime = (p1->runtime) * 1000;
		p1->arrivetime = (p1->arrivetime) * 1000;
		p1->state = R; //就绪状态
		if ((unsigned long)(p1->arrivetime) > max)
			max = p1->arrivetime; //最后一个到达的时间
		p2 = p1;
	}
	p2->next = NULL;
}
void main()
{
	printf("\ntime 1 = 1000 time slice\n");
	current = 0;
	inputprocess(); //输入进程信息
	readyprocess(); //进程调度算法
	getchar();
}