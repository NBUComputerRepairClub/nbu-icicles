//4个进程共享一类资源
#include <iostream>
#include <vector>
// #include <fstream>
using namespace std;
const int TASK_RUNNING = 0; //进程执行状态
const int TASK_SUCCEED = 1; //进程就绪状态
const int TASK_WAITTING = 2; //进程挂起状态
const int RLength = 10;  //总资源数10个
int Rcs_left = RLength;  //可用资源数  Available
// ofstream ff("result.txt");
class pcb  //进程块
{
public:
    int p_pid;  
    int p_stat;  //进程状态
    int p_apply; //进程申请资源数 
    int p_occupy; //进程占用多少 Max
    bool p_issuc; //是否满足 fnish
    int p_require; //需要总资源数
    pcb(int id, int require)
    {
        p_pid = id; 
        p_require = require;
        p_stat = TASK_RUNNING;
        p_occupy = 0;
        p_issuc = false;
        p_apply = 0;
    }
    friend ostream &operator<<(ostream &cout, const pcb &p) //输出
    {
        cout << p.p_pid << '\t' << p.p_stat << '\t' << p.p_require << '\t' << p.p_occupy << endl;
        return cout;
    }
};
void rand(/*vector<int>&resource,*/ vector<pcb> &pgrp);
void banker(/*vector<int>&resource,*/ vector<pcb> &pgrp);

int main()
{
    vector<pcb> pgrp;
    cout << "ENTER THE MAX NUMBER FOR THE REQESTED RESOURCE:" << endl;
    cout << "ID\tREQUESTED" << endl;
    int qty;
    for (int i(1); i <= 4; i++) //输入4个进程需要的资源数
    {
        do
        {
            cout << i << '\t';
            cin >> qty;
        } while (qty > Rcs_left || qty < 1);
        pgrp.insert(pgrp.begin(), pcb(i, qty));
    }
    cout << "ALOGRITHM" << endl
         << "Random(R)" << '\t' << "Banker(B)" << endl
         << "ANY OTHER KEY TO QUIT" << endl;
    char choice;
    cin >> choice;  //算法选择
    if (choice == 'R' || choice == 'r')
        rand(/*resource,*/ pgrp);  //随机算法
    else if (choice == 'B' || choice == 'b')
        banker(/*resource,*/ pgrp); //银行家算法
    else
        return 0;
    return 1;
}
void rand(/*vector<int>&resource,*/ vector<pcb> &pgrp)
{
    vector<pcb>::iterator p, q;
    vector<pcb>::iterator current;
    int temp;
    cout << "NOW--------RANDOM ALOGRITHM" << endl;
    for (;;)
    {
        for (p = pgrp.begin(); p != pgrp.end(); p++)
        {
            if (p->p_stat == TASK_RUNNING)
            {
                current = p;
                break;
            }
        }
        if (current->p_apply == 0)
        {
            cout << "ENTER THE APPLY FOR THE PROCESS\n"
                 << current->p_pid << '\t';
            cin >> temp;
            while (temp > p->p_require - p->p_occupy)
            {
                cout << "beyond the real need!" << endl;
                cout << "ENTER THE APPLY FOR THE PROCESS\n"
                     << current->p_pid << '\t';
                cin >> temp;
            }
            p->p_apply = temp;
        }
        if (current->p_apply > Rcs_left)
        {
            current->p_stat = TASK_WAITTING;
            cout << endl
                 << current->p_pid << "is waitting\n";
            for (p = pgrp.begin(); p != pgrp.end(); p++)
            {
                if (p->p_stat == TASK_RUNNING)
                    break;
            }
            if (p == pgrp.end())
            {
                cout << "LOCKED!!!" << endl;
                exit(1);
            }
            continue;
        }
        cout << temp << "\tresource are accepted for" << p->p_pid << endl;
        cout << endl;
        Rcs_left -= current->p_apply;
        current->p_occupy += current->p_apply;
        current->p_apply = 0;
        if (current->p_occupy < current->p_require)
        {
            pcb proc(*current);
            pgrp.erase(current);
            pgrp.insert(pgrp.end(), proc);
            continue;
        }
        cout << endl
             << "process\t" << p->p_pid << "\thas succeed!!" << endl;
        Rcs_left += current->p_occupy;
        current->p_stat = TASK_SUCCEED;
        for (p = pgrp.begin(); p != pgrp.end(); p++)
        {
            if (p->p_stat == TASK_WAITTING)
                break;
        }
        if (p == pgrp.end())
        {
            for (q = pgrp.begin(); q != pgrp.end(); q++)
                if (q->p_stat == TASK_RUNNING)
                    break;
            if (q == pgrp.end())
            {
                cout << "SUCCEED!!" << endl;
                exit(0);
            }
            else
                continue;
        }
        for (p = pgrp.begin(); p != pgrp.end(); p++)
        {
            if (p->p_stat == TASK_WAITTING && Rcs_left >= p->p_apply)
                break;
        }
        if (p != pgrp.end())
        {
            p->p_stat = TASK_RUNNING;
            pcb proc(*p);
            pgrp.erase(p);
            pgrp.insert(pgrp.end(), proc);
            continue;
        }
    }
}
void banker(/*vector<int>&resource,*/ vector<pcb> &pgrp)
{
    vector<pcb>::iterator p;
    vector<pcb>::iterator current, q;
    pcb proc(0, 0);
    int length;
    cout << "NOW--------BANKER ALOGRITHM" << endl;
    for (;;)
    {
        for (p = pgrp.begin(); p != pgrp.end(); p++) /* 找到运行进程 */
        {
            if (p->p_stat == TASK_RUNNING)
            {
                current = p;
                break;
            }
        }
        if (current->p_apply == 0) /* 输入申请资源数 */
        {
            cout << "ENTER THE APPLY FOR THE PROCESS\n"
                 << current->p_pid << '\t';
            cin >> current->p_apply;  //申请资源数
            while (current->p_apply > current->p_require - current->p_occupy) //申请资源数>需要-占有
            {
                cout << "beyond the real need!" << endl;
                cout << "ENTER THE APPLY FOR THE PROCESS\n"
                     << current->p_pid << '\t';
                cin >> current->p_apply;  //重新输入申请资源数
            }
        }
        if (current->p_apply > Rcs_left)  //申请>可用资源数
        {
            current->p_stat = TASK_WAITTING;  //挂起等待
            proc = *current;
            pgrp.erase(current);
            pgrp.insert(pgrp.end(), proc);
            cout << endl
                 << p->p_pid << " is waitting!\n";
            continue;  //跳过后面代码
        }
        //执行分配资源
        pcb backup(*current);
        length = Rcs_left;  //可用资源数
        current->p_occupy += current->p_apply;//占有增加
        length -= current->p_apply;  //可用资源数 预减少
        if (current->p_occupy == current->p_require) //占有的==需要的，释放
        {
            length += current->p_require;  //可用资源数 预增加
            current->p_issuc = true;    //这次请求后满足需要
        }
        int flag = 1;
        while (flag == 1)
        {
            flag = 0;
            for (p = pgrp.begin(); p != pgrp.end(); p++)  //查找需要资源能满足的进程， 标记完成 （算法核心123步）
            {
                if (p->p_stat == TASK_SUCCEED) //进程状态完成跳过
                    continue;
                if (p->p_issuc == true) //这次请求后满足需要跳过
                    continue;
                if ((p->p_require - p->p_occupy) > length) //需要资源不足的跳过
                    continue;
                else //进程状态未完成，这次请求后不满足，但需要资源足够，分配释放
                {
                    p->p_issuc = true;
                    length += p->p_occupy;
                    flag = 1;
                    cout << p->p_pid << " " << p->p_occupy << " " << length << endl;
                    continue;
                }
            }
        }
        //p指向下一个未结束的进程，无解或进程都已完成
        for (p = pgrp.begin(); p != pgrp.end(); p++)
        {
            if (p->p_issuc == false && p->p_stat != TASK_SUCCEED)//存在进程此次分配未完成，并进程也未完成退出
                break;
        }
        //无解，死锁
        if (p != pgrp.end())
        {
            current->p_occupy = backup.p_occupy;//进当前程完成占用
            current->p_stat = TASK_WAITTING;//进当前程完成占用，挂起
            cout << endl
                 << current->p_pid << " is waitting." << endl;
            proc = *current;
            pgrp.erase(current);
            pgrp.insert(pgrp.end(), proc);
            for (p = pgrp.begin(); p != pgrp.end(); p++)
                p->p_issuc = false;
            continue;//下一次进程处理
        }
        //计算有解，可完成，进行分配
        Rcs_left -= current->p_apply;//更新可用资源
        cout << endl
             << current->p_pid << " get " << current->p_apply << " resource(s)!" << endl;
        current->p_apply = 0;
        for (p = pgrp.begin(); p != pgrp.end(); p++)//进程块中程序均未执行完成，恢复
            p->p_issuc = false;
        if (current->p_occupy < current->p_require)//当前占用<需要资源数
        {
            proc = *current;
            pgrp.erase(current);
            pgrp.insert(pgrp.end(), proc);//插入进程到队尾
            continue;//下一次进程处理
        }
        //当前占用>=需要,完成释放
        current->p_stat = TASK_SUCCEED;
        current->p_occupy = 0;
        cout << endl
             << current->p_pid << " has finished!!!" << endl;
        Rcs_left += current->p_require;
        for (p = pgrp.begin(); p != pgrp.end(); p++)//p指向下一个挂起进程
        {
            if (p->p_stat == TASK_WAITTING)
                break;
        }
        //  判断程序结束
        if (p == pgrp.end()) //所有进程均不挂起
        {
            for (q = pgrp.begin(); q != pgrp.end(); q++)//所有进程均不在判断
                if (q->p_stat == TASK_RUNNING)
                    break;
            if (q == pgrp.end())
            {
                cout << endl
                     << "SUCCEED!!" << endl;
                exit(0);//完成退出
            }
            else
                continue;
        }
        p->p_stat = TASK_RUNNING;//挂起进入就绪行状态，下一次处理
        continue;
    }
}